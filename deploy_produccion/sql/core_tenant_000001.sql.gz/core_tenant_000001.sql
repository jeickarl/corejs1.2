-- MariaDB dump 10.19  Distrib 10.4.32-MariaDB, for Win64 (AMD64)
--
-- Host: 127.0.0.1    Database: core_tenant_000001
-- ------------------------------------------------------
-- Server version	10.4.32-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Current Database: `core_tenant_000001`
--

/*!40000 DROP DATABASE IF EXISTS `core_tenant_000001`*/;

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `core_tenant_000001` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish_ci */;

USE `core_tenant_000001`;

--
-- Table structure for table `accessories_checklist`
--

DROP TABLE IF EXISTS `accessories_checklist`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `accessories_checklist` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(150) NOT NULL,
  `description` text DEFAULT NULL,
  `sort_order` int(10) unsigned NOT NULL DEFAULT 0,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `accessories_checklist`
--

LOCK TABLES `accessories_checklist` WRITE;
/*!40000 ALTER TABLE `accessories_checklist` DISABLE KEYS */;
/*!40000 ALTER TABLE `accessories_checklist` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `activity_logs`
--

DROP TABLE IF EXISTS `activity_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `activity_logs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `action` varchar(255) NOT NULL,
  `table_name` varchar(255) DEFAULT NULL,
  `record_id` int(11) DEFAULT NULL,
  `old_values` text DEFAULT NULL,
  `new_values` text DEFAULT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `activity_logs`
--

LOCK TABLES `activity_logs` WRITE;
/*!40000 ALTER TABLE `activity_logs` DISABLE KEYS */;
/*!40000 ALTER TABLE `activity_logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `billing_config`
--

DROP TABLE IF EXISTS `billing_config`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `billing_config` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `config_key` varchar(150) NOT NULL,
  `config_value` text NOT NULL,
  `config_type` enum('json','string','number') NOT NULL DEFAULT 'json',
  `description` varchar(255) DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_billing_config_key` (`config_key`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `billing_config`
--

LOCK TABLES `billing_config` WRITE;
/*!40000 ALTER TABLE `billing_config` DISABLE KEYS */;
INSERT INTO `billing_config` VALUES (1,'payment_methods','[\"Efectivo\",\"Transferencia\",\"Tarjeta\"]','json','M??todos de pago disponibles para el m??dulo de facturaci??n','2025-10-19 17:42:22','2026-04-19 23:42:23');
/*!40000 ALTER TABLE `billing_config` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `brands`
--

DROP TABLE IF EXISTS `brands`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `brands` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `description` text DEFAULT NULL,
  `logo_path` varchar(255) DEFAULT NULL,
  `logo` varchar(255) DEFAULT NULL,
  `logo_url` varchar(255) NOT NULL DEFAULT '',
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `tenant_id` int(11) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_brands_name_tenant` (`name`,`tenant_id`),
  KEY `idx_brands_tenant` (`tenant_id`)
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `brands`
--

LOCK TABLES `brands` WRITE;
/*!40000 ALTER TABLE `brands` DISABLE KEYS */;
INSERT INTO `brands` VALUES (1,'ASUS','',NULL,'uploads/brands/ASUS.png','',1,'2025-09-03 06:45:51','2026-04-20 04:42:25',1),(2,'HP','',NULL,'uploads/brands/HP.png','',1,'2025-09-03 06:47:53','2026-04-20 04:42:25',1),(3,'Apple','Marca Apple','/api/uploads/1/brands/logo_apple.png','/api/uploads/1/brands/logo_apple.png','',1,'2025-09-04 14:44:02','2026-06-12 03:48:03',1),(4,'Samsung','Marca Samsung','/api/uploads/1/brands/logo_samsung.png','/api/uploads/1/brands/logo_samsung.png','',1,'2025-09-04 14:44:02','2026-06-12 03:48:03',1),(5,'Huawei','Marca Huawei','/api/uploads/1/brands/logo_huawei.png','/api/uploads/1/brands/logo_huawei.png','',1,'2025-09-04 14:44:02','2026-06-12 03:48:03',1),(6,'Xiaomi','Marca Xiaomi','/api/uploads/1/brands/logo_xiaomi.png','/api/uploads/1/brands/logo_xiaomi.png','',1,'2025-09-04 14:44:02','2026-06-12 03:48:03',1),(7,'LG','Marca LG','/api/uploads/1/brands/logo_lg.png','/api/uploads/1/brands/logo_lg.png','',1,'2025-09-04 14:44:02','2026-06-12 03:48:03',1),(8,'Dell','Marca Dell','/api/uploads/1/brands/logo_dell.png','/api/uploads/1/brands/logo_dell.png','',1,'2025-09-04 14:44:02','2026-06-12 03:48:03',1),(9,'Lenovo','Marca Lenovo','/api/uploads/1/brands/logo_lenovo.png','/api/uploads/1/brands/logo_lenovo.png','',1,'2025-09-04 14:44:02','2026-06-12 03:48:03',1),(10,'Acer','Marca Acer.','/api/uploads/1/brands/logo_acer.png','/api/uploads/1/brands/logo_acer.png','',1,'2025-09-04 14:44:02','2026-06-12 03:48:03',1),(11,'MSI','Marca MSI','/api/uploads/1/brands/logo_msi.png','/api/uploads/1/brands/logo_msi.png','',1,'2025-09-04 14:44:02','2026-06-12 03:48:03',1),(12,'Toshiba','Marca Toshiba','/api/uploads/1/brands/logo_toshiba.png','/api/uploads/1/brands/logo_toshiba.png','',1,'2025-09-04 14:44:02','2026-06-12 03:48:03',1),(13,'Epson','Marca Epson','/api/uploads/1/brands/logo_epson.png','/api/uploads/1/brands/logo_epson.png','',1,'2025-09-04 14:44:02','2026-06-12 03:48:03',1),(14,'Nintendo','Marca Nintendo','/api/uploads/1/brands/logo_nintendo.png','/api/uploads/1/brands/logo_nintendo.png','',1,'2025-09-04 14:44:02','2026-06-12 03:48:03',1),(15,'Microsoft','Marca Microsoft','/api/uploads/1/brands/logo_microsoft.png','/api/uploads/1/brands/logo_microsoft.png','',1,'2025-09-04 14:44:02','2026-06-12 03:48:03',1),(16,'Quanta Computer','',NULL,'uploads/brands/Quanta_Computer.png','',1,'2025-10-20 19:04:25','2026-04-20 04:42:25',1),(17,'NVIDIA','','/api/uploads/1/brands/logo_nvidia.png','/api/uploads/1/brands/logo_nvidia.png','',1,'2026-05-02 00:35:04','2026-06-12 03:48:03',1),(18,'GIGABYTE','','/api/uploads/1/brands/logo_gigabyte.png','/api/uploads/1/brands/logo_gigabyte.png','',1,'2026-05-02 00:35:04','2026-06-12 03:48:03',1),(19,'AMD','','/api/uploads/1/brands/logo_amd.png','/api/uploads/1/brands/logo_amd.png','',1,'2026-05-02 01:34:57','2026-06-12 03:48:03',1),(20,'Compumax','','/api/uploads/1/brands/logo_compumax.png','/api/uploads/1/brands/logo_compumax.png','',1,'2026-05-02 01:37:13','2026-06-12 03:48:03',1),(21,'Logitech','','/api/uploads/1/brands/logo_logitech.png','/api/uploads/1/brands/logo_logitech.png','',1,'2026-05-02 01:40:28','2026-06-12 03:48:03',1),(22,'Genius','','/api/uploads/1/brands/logo_genius.png','/api/uploads/1/brands/logo_genius.png','',1,'2026-05-02 01:42:13','2026-06-12 03:48:03',1);
/*!40000 ALTER TABLE `brands` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache`
--

DROP TABLE IF EXISTS `cache`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cache` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `k` varchar(191) NOT NULL,
  `v` longtext DEFAULT NULL,
  `expires_at` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_cache_k` (`k`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache`
--

LOCK TABLES `cache` WRITE;
/*!40000 ALTER TABLE `cache` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cash_closing_denominations`
--

DROP TABLE IF EXISTS `cash_closing_denominations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cash_closing_denominations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cash_session_id` int(10) unsigned NOT NULL,
  `denomination_value` decimal(10,2) NOT NULL,
  `quantity` int(11) NOT NULL,
  `subtotal` decimal(10,2) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `cash_session_id` (`cash_session_id`),
  CONSTRAINT `cash_closing_denominations_ibfk_1` FOREIGN KEY (`cash_session_id`) REFERENCES `cash_sessions` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cash_closing_denominations`
--

LOCK TABLES `cash_closing_denominations` WRITE;
/*!40000 ALTER TABLE `cash_closing_denominations` DISABLE KEYS */;
/*!40000 ALTER TABLE `cash_closing_denominations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cash_expenses`
--

DROP TABLE IF EXISTS `cash_expenses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cash_expenses` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `cash_session_id` int(10) unsigned NOT NULL,
  `concept` varchar(255) NOT NULL,
  `category_id` int(11) DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `receipt_image` varchar(255) DEFAULT NULL,
  `amount` decimal(12,2) NOT NULL,
  `payment_method` varchar(100) DEFAULT NULL,
  `reference_number` varchar(50) DEFAULT NULL,
  `created_by` int(10) unsigned DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `tenant_id` int(11) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`),
  KEY `idx_expenses_session` (`cash_session_id`),
  KEY `fk_expense_category` (`category_id`),
  KEY `idx_cash_expenses_tenant` (`tenant_id`),
  CONSTRAINT `fk_expense_category` FOREIGN KEY (`category_id`) REFERENCES `transaction_categories` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_expenses_session` FOREIGN KEY (`cash_session_id`) REFERENCES `cash_sessions` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cash_expenses`
--

LOCK TABLES `cash_expenses` WRITE;
/*!40000 ALTER TABLE `cash_expenses` DISABLE KEYS */;
/*!40000 ALTER TABLE `cash_expenses` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cash_income`
--

DROP TABLE IF EXISTS `cash_income`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cash_income` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `cash_session_id` int(10) unsigned NOT NULL,
  `income_type` enum('manual','product','service','other') DEFAULT 'manual',
  `concept_id` int(10) unsigned DEFAULT NULL,
  `concept` varchar(255) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `amount` decimal(12,2) NOT NULL,
  `reference_number` varchar(50) DEFAULT NULL,
  `payment_method` varchar(100) NOT NULL,
  `category_id` int(11) DEFAULT NULL,
  `created_by` int(10) unsigned DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `payment_account_id` int(11) DEFAULT NULL,
  `tenant_id` int(11) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`),
  KEY `idx_income_session` (`cash_session_id`),
  KEY `idx_income_method` (`payment_method`),
  KEY `fk_income_category` (`category_id`),
  KEY `idx_cash_income_tenant` (`tenant_id`),
  CONSTRAINT `fk_income_category` FOREIGN KEY (`category_id`) REFERENCES `transaction_categories` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_income_session` FOREIGN KEY (`cash_session_id`) REFERENCES `cash_sessions` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cash_income`
--

LOCK TABLES `cash_income` WRITE;
/*!40000 ALTER TABLE `cash_income` DISABLE KEYS */;
/*!40000 ALTER TABLE `cash_income` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cash_movements`
--

DROP TABLE IF EXISTS `cash_movements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cash_movements` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `cash_session_id` int(10) unsigned NOT NULL,
  `movement_type` enum('income','expense','transfer','adjustment') NOT NULL,
  `amount` decimal(12,2) NOT NULL,
  `reference_number` varchar(100) DEFAULT NULL,
  `related_id` int(10) unsigned DEFAULT NULL,
  `description` text DEFAULT NULL,
  `category` varchar(100) DEFAULT NULL,
  `created_by` int(10) unsigned DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_cash_session_id` (`cash_session_id`),
  KEY `idx_movement_type` (`movement_type`),
  KEY `idx_created_at` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cash_movements`
--

LOCK TABLES `cash_movements` WRITE;
/*!40000 ALTER TABLE `cash_movements` DISABLE KEYS */;
/*!40000 ALTER TABLE `cash_movements` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cash_sessions`
--

DROP TABLE IF EXISTS `cash_sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cash_sessions` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `tenant_id` int(11) NOT NULL DEFAULT 1,
  `session_number` varchar(50) NOT NULL,
  `opened_by` int(10) unsigned NOT NULL,
  `opening_date` datetime NOT NULL DEFAULT current_timestamp(),
  `initial_amount` decimal(12,2) NOT NULL DEFAULT 0.00,
  `observations` text DEFAULT NULL,
  `closed_by` int(10) unsigned DEFAULT NULL,
  `closing_date` datetime DEFAULT NULL,
  `final_amount` decimal(12,2) DEFAULT 0.00,
  `total_cash` decimal(12,2) DEFAULT 0.00,
  `total_transfer` decimal(12,2) DEFAULT 0.00,
  `total_card` decimal(12,2) DEFAULT 0.00,
  `total_other` decimal(12,2) DEFAULT 0.00,
  `system_total` decimal(12,2) DEFAULT 0.00,
  `physical_count` decimal(12,2) DEFAULT 0.00,
  `difference` decimal(12,2) DEFAULT 0.00,
  `closing_notes` text DEFAULT NULL,
  `status` enum('open','closed') NOT NULL DEFAULT 'open',
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_session_tenant` (`session_number`,`tenant_id`),
  KEY `idx_sessions_status` (`status`),
  KEY `idx_sessions_opening` (`opening_date`),
  KEY `idx_sessions_opened_by` (`opened_by`),
  KEY `idx_tenant` (`tenant_id`),
  CONSTRAINT `fk_cash_sessions_tenant` FOREIGN KEY (`tenant_id`) REFERENCES `tenants` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cash_sessions`
--

LOCK TABLES `cash_sessions` WRITE;
/*!40000 ALTER TABLE `cash_sessions` DISABLE KEYS */;
/*!40000 ALTER TABLE `cash_sessions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `clients`
--

DROP TABLE IF EXISTS `clients`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `clients` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `client_number` int(11) NOT NULL DEFAULT 0,
  `tenant_id` int(11) NOT NULL DEFAULT 1,
  `client_type` enum('individual','company') DEFAULT 'individual',
  `first_name` varchar(100) DEFAULT NULL,
  `company_name` varchar(200) DEFAULT NULL,
  `tax_id` varchar(50) DEFAULT NULL,
  `legal_representative` varchar(200) DEFAULT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `address` text DEFAULT NULL,
  `id_number` varchar(20) NOT NULL,
  `notes` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_client_tenant` (`client_number`,`tenant_id`),
  KEY `idx_tenant` (`tenant_id`),
  CONSTRAINT `fk_clients_tenant` FOREIGN KEY (`tenant_id`) REFERENCES `tenants` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `clients`
--

LOCK TABLES `clients` WRITE;
/*!40000 ALTER TABLE `clients` DISABLE KEYS */;
/*!40000 ALTER TABLE `clients` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `company_config`
--

DROP TABLE IF EXISTS `company_config`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `company_config` (
  `id` int(11) NOT NULL,
  `company_name` varchar(200) NOT NULL DEFAULT 'Nexar',
  `company_logo` varchar(255) DEFAULT 'company_logo.png',
  `company_phone` varchar(50) DEFAULT NULL,
  `company_email` varchar(255) DEFAULT NULL,
  `company_website` varchar(255) DEFAULT NULL,
  `logo_url` varchar(255) NOT NULL DEFAULT '',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `company_address` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `company_config`
--

LOCK TABLES `company_config` WRITE;
/*!40000 ALTER TABLE `company_config` DISABLE KEYS */;
INSERT INTO `company_config` VALUES (1,'Empresa_Base','logo_t1_1776659016_657ca403ea92.jpg','+573107031821','jeissonandroi@gmail.com','http://wertwerewrgere','/api/uploads/2/settings/company/logo_empresa.jpeg','2026-04-20 04:23:36','2026-08-23 05:42:47','cll. 11 av. 0 cc gran bulevar loc.213');
/*!40000 ALTER TABLE `company_config` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `company_settings`
--

DROP TABLE IF EXISTS `company_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `company_settings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tenant_id` int(11) NOT NULL DEFAULT 1,
  `company_name` varchar(255) NOT NULL,
  `company_address` text DEFAULT NULL,
  `company_phone` varchar(50) DEFAULT NULL,
  `company_email` varchar(255) DEFAULT NULL,
  `company_website` varchar(255) DEFAULT NULL,
  `tax_id` varchar(50) DEFAULT NULL,
  `logo_path` varchar(500) DEFAULT NULL,
  `background_image` varchar(500) DEFAULT NULL,
  `signature_path` varchar(500) DEFAULT NULL,
  `default_currency` varchar(10) NOT NULL DEFAULT 'USD',
  `date_format` varchar(20) NOT NULL DEFAULT 'd/m/Y',
  `number_format` varchar(20) NOT NULL DEFAULT 'en_US',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_tenant` (`tenant_id`),
  CONSTRAINT `fk_company_settings_tenant` FOREIGN KEY (`tenant_id`) REFERENCES `tenants` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `company_settings`
--

LOCK TABLES `company_settings` WRITE;
/*!40000 ALTER TABLE `company_settings` DISABLE KEYS */;
INSERT INTO `company_settings` VALUES (1,1,'Empresa_Base','Dirección de tu empresa',NULL,'jeissonandroi@gmail.com',NULL,NULL,NULL,NULL,NULL,'USD','d/m/Y','en_US','2026-04-15 15:49:50','2026-04-20 04:44:48');
/*!40000 ALTER TABLE `company_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dashboard_notes`
--

DROP TABLE IF EXISTS `dashboard_notes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dashboard_notes` (
  `user_id` int(11) NOT NULL,
  `content` text DEFAULT NULL,
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dashboard_notes`
--

LOCK TABLES `dashboard_notes` WRITE;
/*!40000 ALTER TABLE `dashboard_notes` DISABLE KEYS */;
/*!40000 ALTER TABLE `dashboard_notes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `device_categories`
--

DROP TABLE IF EXISTS `device_categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `device_categories` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `description` text DEFAULT NULL,
  `sort_order` int(11) NOT NULL DEFAULT 0,
  `active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_name` (`name`),
  KEY `idx_active` (`active`),
  KEY `idx_sort` (`sort_order`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `device_categories`
--

LOCK TABLES `device_categories` WRITE;
/*!40000 ALTER TABLE `device_categories` DISABLE KEYS */;
/*!40000 ALTER TABLE `device_categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `device_types`
--

DROP TABLE IF EXISTS `device_types`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `device_types` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `description` text DEFAULT NULL,
  `is_visible` tinyint(1) DEFAULT 1,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `sort_order` int(11) DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `tenant_id` int(11) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_device_types_name_tenant` (`name`,`tenant_id`),
  KEY `idx_device_types_tenant` (`tenant_id`)
) ENGINE=InnoDB AUTO_INCREMENT=51 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `device_types`
--

LOCK TABLES `device_types` WRITE;
/*!40000 ALTER TABLE `device_types` DISABLE KEYS */;
INSERT INTO `device_types` VALUES (1,'portatil','',1,1,2,'2025-09-01 02:31:19','2026-05-02 00:35:04',1),(2,'Motherboard','',1,1,1,'2025-09-02 12:40:13','2026-05-02 00:35:04',1),(4,'PC de Escritorio','Computadoras de escritorio',1,1,7,'2025-09-03 03:28:36','2026-05-02 00:35:04',1),(9,'Consola','Consolas de videojuegos',0,1,10,'2025-09-03 03:28:36','2026-01-22 18:36:00',1),(11,'Monitor','Monitores y pantallas',1,1,12,'2025-09-03 03:28:36','2026-05-02 00:35:04',1),(12,'Impresora','Impresoras y escáneres',0,1,13,'2025-09-03 03:28:36','2026-05-02 00:35:04',1),(14,'Otros','Otros dispositivos electrónicos',1,1,16,'2025-09-03 03:28:36','2026-05-02 00:35:04',1),(25,'Teclado','Teclados y periféricos de entrada',0,1,12,'2025-09-03 03:55:02','2026-04-20 02:24:13',1),(28,'Cámara','Cámaras web y de seguridad',0,1,17,'2025-09-03 03:55:02','2026-05-02 00:35:04',1),(31,'Cargador','Cargadores y adaptadores',1,1,19,'2025-09-03 03:55:02','2026-05-02 00:35:04',1),(41,'Consola de Videojuegos','Tipo de dispositivo: Consola de Videojuegos',0,1,9,'2025-09-04 14:44:02','2026-04-20 02:24:13',1),(49,'TARJETA GRAFICA','',1,1,3,'2026-04-20 02:23:00','2026-05-02 00:35:04',1),(50,'All in One','Computadoras todo en uno',1,1,9,'2026-05-02 00:35:04','2026-05-02 00:35:04',1);
/*!40000 ALTER TABLE `device_types` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `document_fields`
--

DROP TABLE IF EXISTS `document_fields`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `document_fields` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `field_key` varchar(100) NOT NULL,
  `field_name` varchar(255) NOT NULL,
  `field_type` enum('text','number','date','currency','boolean','image') NOT NULL,
  `source_table` varchar(100) DEFAULT NULL,
  `source_column` varchar(100) DEFAULT NULL,
  `format_pattern` varchar(255) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `category` enum('client','order','product','company','custom') NOT NULL DEFAULT 'custom',
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `field_key` (`field_key`),
  KEY `idx_category` (`category`),
  KEY `idx_source` (`source_table`,`source_column`)
) ENGINE=InnoDB AUTO_INCREMENT=28 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `document_fields`
--

LOCK TABLES `document_fields` WRITE;
/*!40000 ALTER TABLE `document_fields` DISABLE KEYS */;
INSERT INTO `document_fields` VALUES (1,'client.name','Nombre del Cliente','text','clients','first_name',NULL,'Nombre completo del cliente','client',1,'2025-10-20 20:41:35'),(2,'client.email','Email del Cliente','text','clients','email',NULL,'Dirección de email del cliente','client',1,'2025-10-20 20:41:35'),(3,'client.phone','Teléfono del Cliente','text','clients','phone',NULL,'Número de teléfono del cliente','client',1,'2025-10-20 20:41:35'),(4,'client.address','Dirección del Cliente','text','clients','address',NULL,'Dirección completa del cliente','client',1,'2025-10-20 20:41:35'),(5,'client.tax_id','RUC/CI del Cliente','text','clients','tax_id',NULL,'Número de identificación fiscal','client',1,'2025-10-20 20:41:35'),(6,'order.id','Número de Orden','number','work_orders','id',NULL,'Número único del orden','order',1,'2025-10-20 20:41:35'),(7,'order.created_at','Fecha de Creación','date','work_orders','created_at',NULL,'Fecha de creación de la orden','order',1,'2025-10-20 20:41:35'),(8,'order.device_brand','Marca del Dispositivo','text','work_orders','device_brand',NULL,'Marca del dispositivo','order',1,'2025-10-20 20:41:35'),(9,'order.device_model','Modelo del Dispositivo','text','work_orders','device_model',NULL,'Modelo del dispositivo','order',1,'2025-10-20 20:41:35'),(10,'order.serial_number','Número de Serie','text','work_orders','serial_number',NULL,'Número de serie del dispositivo','order',1,'2025-10-20 20:41:35'),(11,'order.reported_issue','Problema Reportado','text','work_orders','reported_issue',NULL,'Descripción del problema','order',1,'2025-10-20 20:41:35'),(12,'order.diagnosis','Diagnóstico','text','work_orders','diagnosis',NULL,'Diagnóstico técnico','order',1,'2025-10-20 20:41:35'),(13,'order.solution','Solución','text','work_orders','solution',NULL,'Solución aplicada','order',1,'2025-10-20 20:41:35'),(14,'order.estimated_cost','Costo Estimado','currency','work_orders','estimated_cost',NULL,'Costo estimado del servicio','order',1,'2025-10-20 20:41:35'),(15,'order.final_cost','Costo Final','currency','work_orders','final_cost',NULL,'Costo final del servicio','order',1,'2025-10-20 20:41:35'),(16,'order.status','Estado','text','work_orders','status',NULL,'Estado actual de la orden','order',1,'2025-10-20 20:41:35'),(17,'company.name','Nombre de la Empresa','text','company_settings','company_name',NULL,'Nombre de la empresa','company',1,'2025-10-20 20:41:35'),(18,'company.address','Dirección de la Empresa','text','company_settings','company_address',NULL,'Dirección de la empresa','company',1,'2025-10-20 20:41:35'),(19,'company.phone','Teléfono de la Empresa','text','company_settings','company_phone',NULL,'Teléfono de la empresa','company',1,'2025-10-20 20:41:35'),(20,'company.email','Email de la Empresa','text','company_settings','company_email',NULL,'Email de la empresa','company',1,'2025-10-20 20:41:35'),(21,'company.website','Sitio Web','text','company_settings','company_website',NULL,'Sitio web de la empresa','company',1,'2025-10-20 20:41:35'),(22,'company.tax_id','RUC de la Empresa','text','company_settings','tax_id',NULL,'RUC de la empresa','company',1,'2025-10-20 20:41:35'),(23,'company.logo','Logo de la Empresa','image','company_settings','logo_path',NULL,'Logo de la empresa','company',1,'2025-10-20 20:41:35'),(24,'current.date','Fecha Actual','date',NULL,NULL,NULL,'Fecha actual del sistema','custom',1,'2025-10-20 20:41:35'),(25,'current.time','Hora Actual','text',NULL,NULL,NULL,'Hora actual del sistema','custom',1,'2025-10-20 20:41:35'),(26,'document.number','Número de Documento','text','documents','document_number',NULL,'Número único del documento','custom',1,'2025-10-20 20:41:35'),(27,'document.title','Título del Documento','text','documents','title',NULL,'Título del documento','custom',1,'2025-10-20 20:41:35');
/*!40000 ALTER TABLE `document_fields` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `document_templates`
--

DROP TABLE IF EXISTS `document_templates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `document_templates` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL COMMENT 'Ej: Ticket Venta 80mm',
  `module_type` enum('work_order','sale','quote','report') NOT NULL,
  `paper_size` enum('letter','half_letter','legal','ticket_80mm','ticket_58mm','sticker_50x25') NOT NULL DEFAULT 'letter',
  `content_html` mediumtext NOT NULL COMMENT 'Estructura HTML con variables {{var}}',
  `content_css` text DEFAULT NULL COMMENT 'Estilos CSS especÝficos',
  `is_active` tinyint(1) DEFAULT 1,
  `is_default` tinyint(1) DEFAULT 0 COMMENT 'Si es la plantilla por defecto para este m¾dulo',
  `created_at` datetime DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT NULL ON UPDATE current_timestamp(),
  `created_by` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `document_templates`
--

LOCK TABLES `document_templates` WRITE;
/*!40000 ALTER TABLE `document_templates` DISABLE KEYS */;
INSERT INTO `document_templates` VALUES (1,'Plantilla1','work_order','letter','\r\n<!-- Rendered Document -->\r\n<div id=\"document-root\" style=\"position: relative; width: 100%; height: 100%;\">\r\n<div class=\"doc-block\" id=\"blk_17699887862994jyo2\" style=\"position: absolute; left: 40px; top: 30px; width: 60px; height: 60px; box-sizing: border-box;\"><div style=\"width: 100%; height: 100%; display: flex; justify-content: flex-start;\">\r\n                <img src=\"https://via.placeholder.com/60x60.png?text=Logo\" style=\"width: 100%; height: 100%; object-fit: contain; display: block;\">\r\n            </div></div>\r\n<div class=\"doc-block\" id=\"blk_1769988786299b5o2l\" style=\"position: absolute; left: 85px; top: 25px; width: 100px; height: auto; box-sizing: border-box;\"><div style=\"text-align: left; font-size: 16px; color: #d1d5db; background-color: transparent; border: 1px solid transparent; padding: 4px; white-space: pre-wrap;\">Nexar</div></div>\r\n<div class=\"doc-block\" id=\"blk_17699887862999hpmh\" style=\"position: absolute; left: 290px; top: 45px; width: 150px; height: auto; box-sizing: border-box;\"><div style=\"text-align: left; font-size: 11px; color: #d1d5db; background-color: transparent; border: 1px solid transparent; padding: 4px; white-space: pre-wrap;\">+573107031821\r\ncll.11av.0cc gran bulevar loc.213\r\nnexar</div></div>\r\n<div class=\"doc-block\" id=\"blk_1769988786299fnl6i\" style=\"position: absolute; left: 190px; top: 35px; width: 100px; height: auto; box-sizing: border-box;\">\r\n            <div style=\"text-align: center;\">\r\n                <img src=\"https://api.qrserver.com/v1/create-qr-code/?size=60x60&data=ORD-000006\" \r\n                     style=\"width: 60px; height: 60px; display: inline-block;\">\r\n            </div>\r\n        </div>\r\n<div class=\"doc-block\" id=\"blk_1769988786299u3093\" style=\"position: absolute; left: 585px; top: 20px; width: 140px; height: 25px; box-sizing: border-box;\"><div style=\"width: 100%; height: 100%; background-color: #d1d5db; border: 1px solid transparent;\"></div></div>\r\n<div class=\"doc-block\" id=\"blk_17699887862992n607\" style=\"position: absolute; left: 630px; top: 20px; width: 100px; height: auto; box-sizing: border-box;\"><div style=\"text-align: left; font-size: 14px; color: #000000; background-color: transparent; border: 1px solid transparent; padding: 4px; white-space: pre-wrap;\">ORDEN DE SERVICIO</div></div>\r\n<div class=\"doc-block\" id=\"blk_1769988786299sqn5l\" style=\"position: absolute; left: 585px; top: 45px; width: 100px; height: auto; box-sizing: border-box;\"><div style=\"text-align: left; font-size: 14px; color: #000000; background-color: transparent; border: 1px solid transparent; padding: 4px; white-space: pre-wrap;\">N??mero:</div></div>\r\n<div class=\"doc-block\" id=\"blk_176998878629986xtr\" style=\"position: absolute; left: 655px; top: 45px; width: 100px; height: auto; box-sizing: border-box;\"><div style=\"text-align: left; font-size: 14px; color: #ef4444; background-color: transparent; border: 1px solid transparent; padding: 4px; white-space: pre-wrap;\">{{order.id}}</div></div>\r\n<div class=\"doc-block\" id=\"blk_17699887862991xc00\" style=\"position: absolute; left: 585px; top: 65px; width: 100px; height: auto; box-sizing: border-box;\"><div style=\"text-align: left; font-size: 14px; color: #000000; background-color: transparent; border: 1px solid transparent; padding: 4px; white-space: pre-wrap;\">Fecha:</div></div>\r\n<div class=\"doc-block\" id=\"blk_17699887862996n0ye\" style=\"position: absolute; left: 655px; top: 65px; width: 100px; height: auto; box-sizing: border-box;\"><div style=\"text-align: left; font-size: 14px; color: #000000; background-color: transparent; border: 1px solid transparent; padding: 4px; white-space: pre-wrap;\">{{order.created_at}}</div></div>\r\n<div class=\"doc-block\" id=\"blk_1769988786299l0aqy\" style=\"position: absolute; left: 40px; top: 100px; width: 340px; height: 25px; box-sizing: border-box;\"><div style=\"width: 100%; height: 100%; background-color: #d1d5db; border: 1px solid transparent;\"></div></div>\r\n<div class=\"doc-block\" id=\"blk_176998878629910sqe\" style=\"position: absolute; left: 155px; top: 100px; width: 100px; height: auto; box-sizing: border-box;\"><div style=\"text-align: left; font-size: 14px; color: #000000; background-color: transparent; border: 1px solid transparent; padding: 4px; white-space: pre-wrap;\">DATOS DEL CLIENTE</div></div>\r\n<div class=\"doc-block\" id=\"blk_17699887862993gywo\" style=\"position: absolute; left: 390px; top: 100px; width: 335px; height: 25px; box-sizing: border-box;\"><div style=\"width: 100%; height: 100%; background-color: #d1d5db; border: 1px solid transparent;\"></div></div>\r\n<div class=\"doc-block\" id=\"blk_176998878629900aj0\" style=\"position: absolute; left: 490px; top: 100px; width: 150px; height: auto; box-sizing: border-box;\"><div style=\"text-align: left; font-size: 14px; color: #000000; background-color: transparent; border: 1px solid transparent; padding: 4px; white-space: pre-wrap;\">DATOS DEL EQUIPO</div></div>\r\n<div class=\"doc-block\" id=\"blk_17699887862997645o\" style=\"position: absolute; left: 40px; top: 130px; width: 100px; height: auto; box-sizing: border-box;\"><div style=\"text-align: left; font-size: 14px; color: #000000; background-color: transparent; border: 1px solid transparent; padding: 4px; white-space: pre-wrap;\">Nombre:</div></div>\r\n<div class=\"doc-block\" id=\"blk_176998878629929007\" style=\"position: absolute; left: 100px; top: 130px; width: 280px; height: auto; box-sizing: border-box;\"><div style=\"text-align: left; font-size: 14px; color: #000000; background-color: transparent; border: 1px solid transparent; padding: 4px; white-space: pre-wrap;\">{{client.name}}</div></div>\r\n<div class=\"doc-block\" id=\"blk_1769988786299l6006\" style=\"position: absolute; left: 40px; top: 150px; width: 100px; height: auto; box-sizing: border-box;\"><div style=\"text-align: left; font-size: 14px; color: #000000; background-color: transparent; border: 1px solid transparent; padding: 4px; white-space: pre-wrap;\">Direcci??n:</div></div>\r\n<div class=\"doc-block\" id=\"blk_176998878629900008\" style=\"position: absolute; left: 100px; top: 150px; width: 280px; height: auto; box-sizing: border-box;\"><div style=\"text-align: left; font-size: 14px; color: #000000; background-color: transparent; border: 1px solid transparent; padding: 4px; white-space: pre-wrap;\">{{client.address}}</div></div>\r\n<div class=\"doc-block\" id=\"blk_176998878629900009\" style=\"position: absolute; left: 40px; top: 170px; width: 100px; height: auto; box-sizing: border-box;\"><div style=\"text-align: left; font-size: 14px; color: #000000; background-color: transparent; border: 1px solid transparent; padding: 4px; white-space: pre-wrap;\">Tel??fono:</div></div>\r\n<div class=\"doc-block\" id=\"blk_176998878629900010\" style=\"position: absolute; left: 100px; top: 170px; width: 280px; height: auto; box-sizing: border-box;\"><div style=\"text-align: left; font-size: 14px; color: #000000; background-color: transparent; border: 1px solid transparent; padding: 4px; white-space: pre-wrap;\">{{client.phone}}</div></div>\r\n<div class=\"doc-block\" id=\"blk_176998878629900011\" style=\"position: absolute; left: 390px; top: 130px; width: 100px; height: auto; box-sizing: border-box;\"><div style=\"text-align: left; font-size: 14px; color: #000000; background-color: transparent; border: 1px solid transparent; padding: 4px; white-space: pre-wrap;\">Equipo:</div></div>\r\n<div class=\"doc-block\" id=\"blk_176998878629900012\" style=\"position: absolute; left: 450px; top: 130px; width: 275px; height: auto; box-sizing: border-box;\"><div style=\"text-align: left; font-size: 14px; color: #000000; background-color: transparent; border: 1px solid transparent; padding: 4px; white-space: pre-wrap;\">{{order.device_brand}} {{order.device_model}}</div></div>\r\n<div class=\"doc-block\" id=\"blk_176998878629900013\" style=\"position: absolute; left: 390px; top: 150px; width: 100px; height: auto; box-sizing: border-box;\"><div style=\"text-align: left; font-size: 14px; color: #000000; background-color: transparent; border: 1px solid transparent; padding: 4px; white-space: pre-wrap;\">Serial:</div></div>\r\n<div class=\"doc-block\" id=\"blk_176998878629900014\" style=\"position: absolute; left: 450px; top: 150px; width: 275px; height: auto; box-sizing: border-box;\"><div style=\"text-align: left; font-size: 14px; color: #000000; background-color: transparent; border: 1px solid transparent; padding: 4px; white-space: pre-wrap;\">{{order.serial_number}}</div></div>\r\n<div class=\"doc-block\" id=\"blk_176998878629900015\" style=\"position: absolute; left: 40px; top: 200px; width: 685px; height: 25px; box-sizing: border-box;\"><div style=\"width: 100%; height: 100%; background-color: #d1d5db; border: 1px solid transparent;\"></div></div>\r\n<div class=\"doc-block\" id=\"blk_176998878629900016\" style=\"position: absolute; left: 330px; top: 200px; width: 150px; height: auto; box-sizing: border-box;\"><div style=\"text-align: left; font-size: 14px; color: #000000; background-color: transparent; border: 1px solid transparent; padding: 4px; white-space: pre-wrap;\">FALLA REPORTADA</div></div>\r\n<div class=\"doc-block\" id=\"blk_176998878629900017\" style=\"position: absolute; left: 40px; top: 230px; width: 685px; height: auto; box-sizing: border-box;\"><div style=\"text-align: left; font-size: 14px; color: #000000; background-color: transparent; border: 1px solid transparent; padding: 4px; white-space: pre-wrap;\">{{order.reported_issue}}</div></div>\r\n<div class=\"doc-block\" id=\"blk_176998878629900018\" style=\"position: absolute; left: 40px; top: 280px; width: 685px; height: 25px; box-sizing: border-box;\"><div style=\"width: 100%; height: 100%; background-color: #d1d5db; border: 1px solid transparent;\"></div></div>\r\n<div class=\"doc-block\" id=\"blk_176998878629900019\" style=\"position: absolute; left: 330px; top: 280px; width: 150px; height: auto; box-sizing: border-box;\"><div style=\"text-align: left; font-size: 14px; color: #000000; background-color: transparent; border: 1px solid transparent; padding: 4px; white-space: pre-wrap;\">TERMINOS Y CONDICIONES</div></div>\r\n<div class=\"doc-block\" id=\"blk_176998878629900020\" style=\"position: absolute; left: 40px; top: 310px; width: 685px; height: auto; box-sizing: border-box;\"><div style=\"text-align: left; font-size: 10px; color: #000000; background-color: transparent; border: 1px solid transparent; padding: 4px; white-space: pre-wrap;\">1. La empresa no se hace responsable por p??rdida de informaci??n.\r\n2. Pasados 30 d??as sin retirar el equipo, se cobrar?? bodegaje.\r\n3. La garant??a cubre solo el servicio realizado.</div></div>\r\n<div class=\"doc-block\" id=\"blk_176998878629900021\" style=\"position: absolute; left: 40px; top: 400px; width: 250px; height: 1px; box-sizing: border-box;\"><div style=\"width: 100%; height: 100%; border-top: 1px solid #000000;\"></div></div>\r\n<div class=\"doc-block\" id=\"blk_176998878629900022\" style=\"position: absolute; left: 475px; top: 400px; width: 250px; height: 1px; box-sizing: border-box;\"><div style=\"width: 100%; height: 100%; border-top: 1px solid #000000;\"></div></div>\r\n<div class=\"doc-block\" id=\"blk_176998878629900023\" style=\"position: absolute; left: 110px; top: 405px; width: 100px; height: auto; box-sizing: border-box;\"><div style=\"text-align: left; font-size: 14px; color: #000000; background-color: transparent; border: 1px solid transparent; padding: 4px; white-space: pre-wrap;\">Firma Cliente</div></div>\r\n<div class=\"doc-block\" id=\"blk_176998878629900024\" style=\"position: absolute; left: 550px; top: 405px; width: 100px; height: auto; box-sizing: border-box;\"><div style=\"text-align: left; font-size: 14px; color: #000000; background-color: transparent; border: 1px solid transparent; padding: 4px; white-space: pre-wrap;\">Firma T??cnico</div></div>\r\n</div>',NULL,1,0,'2025-10-20 20:41:35','2026-04-19 23:42:48',1),(2,'Etiqueta Orden (50x30mm)','','','\n<!-- Rendered Document -->\n<div id=\"document-root\" style=\"position: relative; width: 100%; height: 100%;\">\n<div class=\"doc-block\" id=\"blk_logo\" style=\"position: absolute; left: 2px; top: 2px; width: 26px; height: auto; box-sizing: border-box;\"><div style=\"text-align: left;\"><img src=\"{{empresa_logo}}\" style=\"width: 26px; height: auto; max-width: 100%;\"></div></div><div class=\"doc-block\" id=\"blk_qr\" style=\"position: absolute; left: 160px; top: 2px; width: 26px; height: 26px; box-sizing: border-box;\"><div style=\"width: 100%; height: 100%; display: flex; justify-content: center;\"><img src=\"{{qr_code_url}}\" style=\"width: 100%; height: 100%; object-fit: contain; display: block;\"></div></div><div class=\"doc-block\" id=\"blk_order\" style=\"position: absolute; left: 2px; top: 32px; width: 186px; height: auto; box-sizing: border-box;\"><div style=\"text-align: left; font-size: 12px; color: #000000; padding: 0; white-space: pre-wrap; font-weight: bold;\">ORDEN {{orden_numero}}</div></div><div class=\"doc-block\" id=\"blk_client\" style=\"position: absolute; left: 2px; top: 50px; width: 186px; height: auto; box-sizing: border-box;\"><div style=\"text-align: left; font-size: 9px; color: #000000; padding: 0; white-space: pre-wrap;\">{{cliente_nombre}}</div></div><div class=\"doc-block\" id=\"blk_device\" style=\"position: absolute; left: 2px; top: 64px; width: 186px; height: auto; box-sizing: border-box;\"><div style=\"text-align: left; font-size: 9px; color: #000000; padding: 0; white-space: pre-wrap;\">{{equipo_marca}} {{equipo_model}}</div></div><div class=\"doc-block\" id=\"blk_serial\" style=\"position: absolute; left: 2px; top: 78px; width: 186px; height: auto; box-sizing: border-box;\"><div style=\"text-align: left; font-size: 9px; color: #000000; padding: 0; white-space: pre-wrap;\">S/N: {{equipo_serie}}</div></div>\n</div>\n\n<!-- Editor State (DO NOT EDIT) -->\n<script id=\"editor-state\" type=\"application/json\">\n{\"blocks\":[{\"id\":\"blk_logo\",\"type\":\"company_logo\",\"props\":{\"src\":\"{{empresa_logo}}\",\"width\":\"26px\",\"height\":\"auto\",\"x\":2,\"y\":2,\"align\":\"left\"}},{\"id\":\"blk_qr\",\"type\":\"image\",\"props\":{\"src\":\"{{qr_code_url}}\",\"width\":\"26px\",\"height\":\"26px\",\"x\":160,\"y\":2,\"objectFit\":\"contain\",\"align\":\"center\"}},{\"id\":\"blk_order\",\"type\":\"text\",\"props\":{\"text\":\"ORDEN {{orden_numero}}\",\"align\":\"left\",\"size\":\"12px\",\"color\":\"#000000\",\"backgroundColor\":\"transparent\",\"borderColor\":\"transparent\",\"x\":2,\"y\":32,\"width\":\"186px\",\"height\":\"auto\"}},{\"id\":\"blk_client\",\"type\":\"text\",\"props\":{\"text\":\"{{cliente_nombre}}\",\"align\":\"left\",\"size\":\"9px\",\"color\":\"#000000\",\"backgroundColor\":\"transparent\",\"borderColor\":\"transparent\",\"x\":2,\"y\":50,\"width\":\"186px\",\"height\":\"auto\"}},{\"id\":\"blk_device\",\"type\":\"text\",\"props\":{\"text\":\"{{equipo_marca}} {{equipo_model}}\",\"align\":\"left\",\"size\":\"9px\",\"color\":\"#000000\",\"backgroundColor\":\"transparent\",\"borderColor\":\"transparent\",\"x\":2,\"y\":64,\"width\":\"186px\",\"height\":\"auto\"}},{\"id\":\"blk_serial\",\"type\":\"text\",\"props\":{\"text\":\"S\\/N: {{equipo_serie}}\",\"align\":\"left\",\"size\":\"9px\",\"color\":\"#000000\",\"backgroundColor\":\"transparent\",\"borderColor\":\"transparent\",\"x\":2,\"y\":78,\"width\":\"186px\",\"height\":\"auto\"}}],\"page\":{\"backgroundColor\":\"#ffffff\",\"width\":50,\"height\":30,\"unit\":\"mm\",\"sizePreset\":\"sticker_5030\",\"layoutMode\":\"absolute\",\"snapToGrid\":true}}\n</script>\n','\n@page { size: 50mm 30mm; margin: 0; }\nhtml, body { margin: 0; padding: 0; width: 50mm; height: 30mm; background-color: #ffffff; font-family: Arial, sans-serif; }\n.doc-block { overflow: hidden; }\n@media print { body { -webkit-print-color-adjust: exact; print-color-adjust: exact; } }\n',1,1,'2026-04-23 00:48:30',NULL,1);
/*!40000 ALTER TABLE `document_templates` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `documents`
--

DROP TABLE IF EXISTS `documents`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `documents` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `template_id` int(11) NOT NULL,
  `reference_type` enum('work_order','sale','purchase_order','client','supplier','manual') NOT NULL,
  `reference_id` int(11) DEFAULT NULL,
  `document_number` varchar(50) DEFAULT NULL,
  `title` varchar(255) NOT NULL,
  `content` longtext NOT NULL,
  `data` longtext DEFAULT NULL CHECK (json_valid(`data`)),
  `file_path` varchar(500) DEFAULT NULL,
  `status` enum('draft','generated','sent','archived') NOT NULL DEFAULT 'draft',
  `generated_by` int(11) NOT NULL,
  `generated_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `sent_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `document_number` (`document_number`),
  KEY `idx_template_id` (`template_id`),
  KEY `idx_reference` (`reference_type`,`reference_id`),
  KEY `idx_document_number` (`document_number`),
  KEY `idx_status` (`status`),
  KEY `idx_generated_by` (`generated_by`),
  CONSTRAINT `documents_ibfk_1` FOREIGN KEY (`template_id`) REFERENCES `document_templates` (`id`) ON DELETE CASCADE,
  CONSTRAINT `documents_ibfk_2` FOREIGN KEY (`generated_by`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `documents`
--

LOCK TABLES `documents` WRITE;
/*!40000 ALTER TABLE `documents` DISABLE KEYS */;
/*!40000 ALTER TABLE `documents` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `equipment_accessories`
--

DROP TABLE IF EXISTS `equipment_accessories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `equipment_accessories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `description` text DEFAULT NULL,
  `category` varchar(50) DEFAULT 'general',
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `sort_order` int(11) NOT NULL DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `tenant_id` int(11) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_equipment_accessories_name_tenant` (`name`,`tenant_id`),
  KEY `idx_equipment_accessories_active` (`is_active`),
  KEY `idx_equipment_accessories_category` (`category`),
  KEY `idx_equipment_accessories_sort` (`sort_order`),
  KEY `idx_equipment_accessories_tenant` (`tenant_id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `equipment_accessories`
--

LOCK TABLES `equipment_accessories` WRITE;
/*!40000 ALTER TABLE `equipment_accessories` DISABLE KEYS */;
INSERT INTO `equipment_accessories` VALUES (1,'Cargador',NULL,'general',1,1,'2026-04-20 02:31:49','2026-04-20 04:42:51',1),(2,'Memoria SD',NULL,'general',1,3,'2026-04-20 02:31:49','2026-04-20 04:42:51',1),(4,'Funda/Case',NULL,'general',1,5,'2026-04-20 02:31:49','2026-04-20 04:42:51',1),(5,'Teclado',NULL,'general',1,6,'2026-04-20 02:31:49','2026-04-20 04:42:51',1),(6,'Mouse',NULL,'general',1,7,'2026-04-20 02:31:49','2026-04-20 04:42:51',1),(7,'Audífonos',NULL,'general',1,8,'2026-04-20 02:31:49','2026-04-20 04:42:51',1),(8,'Batería externa',NULL,'general',1,9,'2026-04-20 02:31:49','2026-04-20 04:42:51',1);
/*!40000 ALTER TABLE `equipment_accessories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `inventory_movements`
--

DROP TABLE IF EXISTS `inventory_movements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `inventory_movements` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tenant_id` int(11) NOT NULL DEFAULT 1,
  `product_id` int(11) NOT NULL,
  `movement_type` enum('in','out','adjustment') NOT NULL,
  `quantity` int(11) NOT NULL,
  `reference_type` varchar(50) DEFAULT NULL,
  `reference_id` int(11) DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_inventory_movements_tenant` (`tenant_id`),
  KEY `idx_inventory_movements_product` (`product_id`),
  KEY `idx_inventory_movements_type` (`movement_type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `inventory_movements`
--

LOCK TABLES `inventory_movements` WRITE;
/*!40000 ALTER TABLE `inventory_movements` DISABLE KEYS */;
/*!40000 ALTER TABLE `inventory_movements` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `inventory_products`
--

DROP TABLE IF EXISTS `inventory_products`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `inventory_products` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tenant_id` int(11) NOT NULL DEFAULT 1,
  `internal_code` varchar(50) DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `category_id` int(11) DEFAULT NULL,
  `brand_id` int(11) DEFAULT NULL,
  `supplier_id` int(11) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `purchase_price` decimal(10,2) NOT NULL DEFAULT 0.00,
  `sale_price` decimal(10,2) NOT NULL DEFAULT 0.00,
  `current_stock` int(11) NOT NULL DEFAULT 0,
  `min_stock` int(11) NOT NULL DEFAULT 0,
  `max_stock` int(11) DEFAULT NULL,
  `location` varchar(100) DEFAULT NULL,
  `unit_type` varchar(50) NOT NULL DEFAULT 'unidad',
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `notes` text DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_internal_code` (`internal_code`),
  KEY `idx_inventory_products_tenant` (`tenant_id`),
  KEY `idx_inventory_products_category` (`category_id`),
  KEY `idx_inventory_products_brand` (`brand_id`),
  KEY `idx_inventory_products_supplier` (`supplier_id`),
  KEY `idx_inventory_products_active` (`is_active`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `inventory_products`
--

LOCK TABLES `inventory_products` WRITE;
/*!40000 ALTER TABLE `inventory_products` DISABLE KEYS */;
/*!40000 ALTER TABLE `inventory_products` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `invoice_drafts`
--

DROP TABLE IF EXISTS `invoice_drafts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `invoice_drafts` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL,
  `draft_data` longtext NOT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_drafts_user` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `invoice_drafts`
--

LOCK TABLES `invoice_drafts` WRITE;
/*!40000 ALTER TABLE `invoice_drafts` DISABLE KEYS */;
/*!40000 ALTER TABLE `invoice_drafts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `invoice_items`
--

DROP TABLE IF EXISTS `invoice_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `invoice_items` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `invoice_id` int(10) unsigned NOT NULL,
  `item_type` enum('manual','product','service') NOT NULL DEFAULT 'manual',
  `description` varchar(255) NOT NULL,
  `product_id` int(10) unsigned DEFAULT NULL,
  `quantity` decimal(12,2) NOT NULL DEFAULT 1.00,
  `unit_price` decimal(12,2) NOT NULL DEFAULT 0.00,
  `total_price` decimal(12,2) NOT NULL DEFAULT 0.00,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `tenant_id` int(11) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`),
  KEY `idx_items_invoice` (`invoice_id`),
  KEY `idx_invoice_items_tenant` (`tenant_id`),
  CONSTRAINT `fk_items_invoice` FOREIGN KEY (`invoice_id`) REFERENCES `invoices` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `invoice_items`
--

LOCK TABLES `invoice_items` WRITE;
/*!40000 ALTER TABLE `invoice_items` DISABLE KEYS */;
/*!40000 ALTER TABLE `invoice_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `invoice_payments`
--

DROP TABLE IF EXISTS `invoice_payments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `invoice_payments` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `invoice_id` int(10) unsigned NOT NULL,
  `payment_amount` decimal(12,2) NOT NULL,
  `payment_method` varchar(100) NOT NULL,
  `payment_date` datetime NOT NULL,
  `reference_number` varchar(100) DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `cash_session_id` int(10) unsigned DEFAULT NULL,
  `created_by` int(10) unsigned DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `pm_account_id` int(11) DEFAULT NULL,
  `tenant_id` int(11) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`),
  KEY `idx_payments_invoice` (`invoice_id`),
  KEY `idx_invoice_payments_tenant` (`tenant_id`),
  CONSTRAINT `fk_payments_invoice` FOREIGN KEY (`invoice_id`) REFERENCES `invoices` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `invoice_payments`
--

LOCK TABLES `invoice_payments` WRITE;
/*!40000 ALTER TABLE `invoice_payments` DISABLE KEYS */;
/*!40000 ALTER TABLE `invoice_payments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `invoices`
--

DROP TABLE IF EXISTS `invoices`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `invoices` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `tenant_id` int(11) NOT NULL DEFAULT 1,
  `invoice_number` varchar(50) NOT NULL,
  `client_id` int(10) unsigned NOT NULL,
  `document_type` varchar(50) DEFAULT NULL,
  `invoice_date` datetime NOT NULL,
  `due_date` date DEFAULT NULL,
  `subtotal` decimal(12,2) NOT NULL DEFAULT 0.00,
  `discount_amount` decimal(12,2) NOT NULL DEFAULT 0.00,
  `tax_amount` decimal(12,2) NOT NULL DEFAULT 0.00,
  `total_amount` decimal(12,2) NOT NULL DEFAULT 0.00,
  `paid_amount` decimal(12,2) NOT NULL DEFAULT 0.00,
  `pending_amount` decimal(12,2) NOT NULL DEFAULT 0.00,
  `payment_status` enum('pending','partial','paid') NOT NULL DEFAULT 'pending',
  `status` enum('draft','sent','paid','cancelled') NOT NULL DEFAULT 'draft',
  `notes` text DEFAULT NULL,
  `terms_conditions` text DEFAULT NULL,
  `created_by` int(10) unsigned DEFAULT NULL,
  `cancelled_by` int(10) unsigned DEFAULT NULL,
  `cancellation_reason` text DEFAULT NULL,
  `cancelled_at` datetime DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `overdue_notified_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_invoice_tenant` (`invoice_number`,`tenant_id`),
  UNIQUE KEY `uq_invoices_invoice_number_tenant` (`invoice_number`,`tenant_id`),
  UNIQUE KEY `uq_invoice_tenant` (`tenant_id`,`invoice_number`),
  KEY `idx_invoices_client` (`client_id`),
  KEY `idx_invoices_date` (`invoice_date`),
  KEY `idx_invoices_status` (`status`),
  KEY `idx_invoices_payment_status` (`payment_status`),
  KEY `idx_tenant` (`tenant_id`),
  CONSTRAINT `fk_invoices_tenant` FOREIGN KEY (`tenant_id`) REFERENCES `tenants` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `invoices`
--

LOCK TABLES `invoices` WRITE;
/*!40000 ALTER TABLE `invoices` DISABLE KEYS */;
/*!40000 ALTER TABLE `invoices` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `models`
--

DROP TABLE IF EXISTS `models`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `models` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `brand_id` int(11) NOT NULL,
  `device_type_id` int(11) NOT NULL,
  `description` text DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `tenant_id` int(11) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`),
  KEY `brand_id` (`brand_id`),
  KEY `device_type_id` (`device_type_id`),
  KEY `idx_models_tenant` (`tenant_id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `models`
--

LOCK TABLES `models` WRITE;
/*!40000 ALTER TABLE `models` DISABLE KEYS */;
INSERT INTO `models` VALUES (1,'G533ZW',1,1,'',1,'2026-04-20 02:02:31','2026-04-20 04:43:12',1),(2,'22-dt0011la',2,50,'',1,'2026-05-02 00:35:04','2026-05-02 00:35:04',1),(3,'GeForce GTX 1060 ARMOR 6G OCV1',1,1,NULL,1,'2026-05-02 00:35:04','2026-05-02 00:35:04',1),(4,'X4415JA-EK2094W',1,1,'',1,'2026-05-02 00:35:04','2026-05-02 00:35:04',1),(5,'A1708',1,2,NULL,1,'2026-05-02 00:35:04','2026-05-02 00:35:04',1),(6,'A314-22-R1C8',10,1,NULL,1,'2026-05-02 00:35:04','2026-05-02 00:35:04',1),(7,'GV-N3050WF2OC-6GD',1,49,NULL,1,'2026-05-02 00:35:04','2026-05-02 00:35:04',1),(8,'15-N284CA',2,2,NULL,1,'2026-05-02 00:35:04','2026-05-02 00:35:04',1),(9,'E1504G',1,1,NULL,1,'2026-05-02 00:35:04','2026-05-02 00:35:04',1),(10,'nm-c781 rev 1.0',1,2,NULL,1,'2026-05-02 00:35:04','2026-05-02 00:35:04',1);
/*!40000 ALTER TABLE `models` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `notifications`
--

DROP TABLE IF EXISTS `notifications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `notifications` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tenant_id` int(11) NOT NULL,
  `type` varchar(50) NOT NULL,
  `title` varchar(255) NOT NULL,
  `body` text DEFAULT NULL,
  `meta` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notifications`
--

LOCK TABLES `notifications` WRITE;
/*!40000 ALTER TABLE `notifications` DISABLE KEYS */;
/*!40000 ALTER TABLE `notifications` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `order_checklist`
--

DROP TABLE IF EXISTS `order_checklist`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `order_checklist` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `order_id` int(11) NOT NULL,
  `checklist_item_id` int(11) NOT NULL,
  `is_checked` tinyint(1) NOT NULL DEFAULT 0,
  `notes` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `order_id` (`order_id`),
  KEY `checklist_item_id` (`checklist_item_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `order_checklist`
--

LOCK TABLES `order_checklist` WRITE;
/*!40000 ALTER TABLE `order_checklist` DISABLE KEYS */;
/*!40000 ALTER TABLE `order_checklist` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `order_equipment_accessories`
--

DROP TABLE IF EXISTS `order_equipment_accessories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `order_equipment_accessories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `order_id` int(11) NOT NULL,
  `accessory_id` int(11) NOT NULL,
  `is_included` tinyint(1) NOT NULL DEFAULT 0,
  `condition_notes` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_order_accessory` (`order_id`,`accessory_id`),
  KEY `idx_order_equipment_accessories_order` (`order_id`),
  KEY `idx_order_equipment_accessories_accessory` (`accessory_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `order_equipment_accessories`
--

LOCK TABLES `order_equipment_accessories` WRITE;
/*!40000 ALTER TABLE `order_equipment_accessories` DISABLE KEYS */;
/*!40000 ALTER TABLE `order_equipment_accessories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `order_items`
--

DROP TABLE IF EXISTS `order_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `order_items` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `order_id` int(11) NOT NULL,
  `service_id` int(11) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `quantity` decimal(12,2) NOT NULL DEFAULT 1.00,
  `unit_price` decimal(12,2) NOT NULL DEFAULT 0.00,
  `discount` decimal(12,2) NOT NULL DEFAULT 0.00,
  `tax_amount` decimal(12,2) NOT NULL DEFAULT 0.00,
  `subtotal` decimal(12,2) NOT NULL DEFAULT 0.00,
  `total` decimal(12,2) NOT NULL DEFAULT 0.00,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_order_id` (`order_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `order_items`
--

LOCK TABLES `order_items` WRITE;
/*!40000 ALTER TABLE `order_items` DISABLE KEYS */;
/*!40000 ALTER TABLE `order_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `order_parts`
--

DROP TABLE IF EXISTS `order_parts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `order_parts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tenant_id` int(11) NOT NULL DEFAULT 1,
  `order_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `quantity_used` decimal(10,2) NOT NULL DEFAULT 1.00,
  `unit_cost` decimal(10,2) NOT NULL DEFAULT 0.00,
  `notes` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `order_id` (`order_id`),
  KEY `product_id` (`product_id`),
  CONSTRAINT `order_parts_ibfk_1` FOREIGN KEY (`order_id`) REFERENCES `work_orders` (`id`) ON DELETE CASCADE,
  CONSTRAINT `order_parts_ibfk_2` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `order_parts`
--

LOCK TABLES `order_parts` WRITE;
/*!40000 ALTER TABLE `order_parts` DISABLE KEYS */;
/*!40000 ALTER TABLE `order_parts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `order_services`
--

DROP TABLE IF EXISTS `order_services`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `order_services` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `work_order_id` int(11) NOT NULL,
  `service_id` int(11) NOT NULL,
  `quantity` int(11) DEFAULT 1,
  `unit_price` decimal(10,2) DEFAULT NULL,
  `total_price` decimal(10,2) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `work_order_id` (`work_order_id`),
  KEY `service_id` (`service_id`),
  CONSTRAINT `order_services_ibfk_1` FOREIGN KEY (`work_order_id`) REFERENCES `work_orders` (`id`) ON DELETE CASCADE,
  CONSTRAINT `order_services_ibfk_2` FOREIGN KEY (`service_id`) REFERENCES `services` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `order_services`
--

LOCK TABLES `order_services` WRITE;
/*!40000 ALTER TABLE `order_services` DISABLE KEYS */;
/*!40000 ALTER TABLE `order_services` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `order_status_history`
--

DROP TABLE IF EXISTS `order_status_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `order_status_history` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `order_id` int(11) NOT NULL,
  `status` enum('pending','received','diagnosing','waiting_parts','repairing','testing','completed','ready','delivered','cancelled','approved','rejected','pendiente','asignado','diagnosticando','esperando_repuestos','reparando','testeando','completado','listo','entregado','cancelado','aprobado','rechazado') NOT NULL,
  `notes` text DEFAULT NULL,
  `changed_by` int(11) DEFAULT NULL,
  `tenant_id` int(11) NOT NULL DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `order_id` (`order_id`),
  KEY `changed_by` (`changed_by`),
  KEY `idx_order_status_history_tenant` (`tenant_id`),
  CONSTRAINT `order_status_history_ibfk_1` FOREIGN KEY (`order_id`) REFERENCES `work_orders` (`id`) ON DELETE CASCADE,
  CONSTRAINT `order_status_history_ibfk_2` FOREIGN KEY (`changed_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `order_status_history`
--

LOCK TABLES `order_status_history` WRITE;
/*!40000 ALTER TABLE `order_status_history` DISABLE KEYS */;
/*!40000 ALTER TABLE `order_status_history` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `order_statuses`
--

DROP TABLE IF EXISTS `order_statuses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `order_statuses` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tenant_id` int(11) NOT NULL DEFAULT 1,
  `slug` varchar(50) NOT NULL,
  `emoji` varchar(10) DEFAULT '',
  `name` varchar(100) NOT NULL,
  `description` text DEFAULT NULL,
  `color` varchar(7) NOT NULL DEFAULT '#007bff',
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `is_default` tinyint(1) NOT NULL DEFAULT 0,
  `sort_order` int(11) NOT NULL DEFAULT 0,
  `is_excluded_from_total` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_order_statuses_slug_tenant` (`slug`,`tenant_id`),
  KEY `idx_order_statuses_tenant` (`tenant_id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `order_statuses`
--

LOCK TABLES `order_statuses` WRITE;
/*!40000 ALTER TABLE `order_statuses` DISABLE KEYS */;
INSERT INTO `order_statuses` VALUES (1,1,'nuevoestad','📦','devolucion','','#6c757d',0,0,13,0,'2025-10-19 22:02:36','2026-04-20 04:43:25'),(2,1,'pendiente','⏳','Pendiente','Orden creada y pendiente de revisión','#ffc107',1,1,1,0,'2026-02-25 16:18:16','2026-04-20 04:43:25'),(3,1,'asignado','📦','Asignado','Dispositivo recibido en el taller','#0644a7',1,0,2,0,'2026-02-25 16:18:16','2026-04-20 04:43:25'),(4,1,'diagnosticando','🔍','Diagnosticando','Equipo en diagnóstico técnico','#fd7e14',1,0,3,0,'2026-02-25 16:18:16','2026-04-20 04:43:25'),(5,1,'esperando_repuestos','⏸️','Esperando Repuestos','Orden en espera de repuestos','#6f42c1',1,0,7,0,'2026-02-25 16:18:16','2026-04-20 04:43:25'),(6,1,'reparando','🔧','Reparando','Equipo en reparación','#007bff',1,0,8,0,'2026-02-25 16:18:16','2026-04-20 04:43:25'),(7,1,'testeando','🧪','Testeando','Equipo en pruebas de funcionamiento','#17a2b8',1,0,9,0,'2026-02-25 16:18:16','2026-04-20 04:43:25'),(8,1,'completado','✅','Completado','Trabajo completado, listo para entrega','#28a745',1,0,10,0,'2026-02-25 16:18:16','2026-04-20 04:43:25'),(9,1,'entregado','🚚','Entregado','Dispositivo entregado al cliente','#6c757d',1,0,11,0,'2026-02-25 16:18:16','2026-04-20 04:43:25'),(10,1,'cancelado','❌','Cancelado','Orden cancelada','#dc3545',1,0,12,0,'2026-02-25 16:18:16','2026-04-20 04:43:25'),(11,1,'aprobado','🟢','Aprobado','Presupuesto aprobado  por el cliente','#0e6723',1,0,6,0,'2026-02-25 16:45:27','2026-04-20 04:43:25'),(12,1,'rechazado','🚫','rechazado','','#000000',1,0,5,0,'2026-03-06 04:48:03','2026-04-20 04:43:25'),(13,1,'esperando_aprobacion','✍️','Esperando Aprobación','Orden esperando aprobación del cliente','#3c3a34',1,0,4,0,'2026-03-11 03:05:13','2026-04-20 04:43:25');
/*!40000 ALTER TABLE `order_statuses` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `orders`
--

DROP TABLE IF EXISTS `orders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `orders` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `order_number` varchar(64) NOT NULL,
  `client_id` int(11) NOT NULL,
  `device_type_id` int(11) DEFAULT NULL,
  `brand_id` int(11) DEFAULT NULL,
  `model_id` int(11) DEFAULT NULL,
  `serial_number` varchar(150) DEFAULT NULL,
  `imei` varchar(50) DEFAULT NULL,
  `password_device` varchar(100) DEFAULT NULL,
  `reported_problem` text DEFAULT NULL,
  `diagnosis` text DEFAULT NULL,
  `work_done` text DEFAULT NULL,
  `internal_notes` text DEFAULT NULL,
  `status` varchar(64) NOT NULL DEFAULT 'pending',
  `priority` enum('low','medium','high','urgent') NOT NULL DEFAULT 'medium',
  `technician_id` int(11) DEFAULT NULL,
  `received_by` int(11) DEFAULT NULL,
  `received_at` datetime DEFAULT NULL,
  `quoted_amount` decimal(12,2) DEFAULT NULL,
  `advance_payment` decimal(12,2) DEFAULT NULL,
  `final_amount` decimal(12,2) DEFAULT NULL,
  `tenant_id` int(11) DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_order_number` (`order_number`),
  KEY `idx_client_id` (`client_id`),
  KEY `idx_status` (`status`),
  KEY `idx_technician_id` (`technician_id`),
  KEY `idx_created_at` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `orders`
--

LOCK TABLES `orders` WRITE;
/*!40000 ALTER TABLE `orders` DISABLE KEYS */;
/*!40000 ALTER TABLE `orders` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `password_reset_tokens`
--

DROP TABLE IF EXISTS `password_reset_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `password_reset_tokens` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `token` varchar(191) NOT NULL,
  `expires_at` datetime NOT NULL,
  `used_at` datetime DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_token` (`token`),
  KEY `idx_user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `password_reset_tokens`
--

LOCK TABLES `password_reset_tokens` WRITE;
/*!40000 ALTER TABLE `password_reset_tokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `password_reset_tokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `payment_method_accounts`
--

DROP TABLE IF EXISTS `payment_method_accounts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `payment_method_accounts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `payment_method_id` int(10) unsigned DEFAULT NULL,
  `method_id` int(11) NOT NULL,
  `account_name` varchar(100) DEFAULT NULL,
  `account_type` varchar(50) NOT NULL DEFAULT '',
  `account_number` varchar(100) NOT NULL,
  `type` varchar(50) DEFAULT NULL,
  `holder_name` varchar(120) DEFAULT NULL,
  `holder_id` varchar(60) DEFAULT NULL,
  `is_default` tinyint(1) NOT NULL DEFAULT 0,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `tenant_id` int(11) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`),
  KEY `method_id` (`method_id`),
  KEY `idx_payment_method_accounts_tenant` (`tenant_id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `payment_method_accounts`
--

LOCK TABLES `payment_method_accounts` WRITE;
/*!40000 ALTER TABLE `payment_method_accounts` DISABLE KEYS */;
INSERT INTO `payment_method_accounts` VALUES (4,3,3,NULL,'ahorros','321986994','ahorros','jeisson arevalo','1090525211',0,1,'2025-11-22 15:27:05','2026-05-25 00:45:34',1),(5,5,5,NULL,'ahorros','43534534','ahorros','werwewer','23423423',0,1,'2025-11-24 20:42:05','2026-05-25 00:45:34',1),(6,6,6,NULL,'ahorros','322323','ahorros','LEON','',1,1,'2026-01-28 00:10:41','2026-05-25 00:45:34',1);
/*!40000 ALTER TABLE `payment_method_accounts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `payment_methods`
--

DROP TABLE IF EXISTS `payment_methods`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `payment_methods` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `status` enum('active','inactive') DEFAULT 'active',
  `tenant_id` int(11) NOT NULL DEFAULT 1,
  `is_default` tinyint(1) NOT NULL DEFAULT 0,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_payment_methods_name_tenant` (`name`,`tenant_id`),
  KEY `idx_payment_methods_tenant` (`tenant_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `payment_methods`
--

LOCK TABLES `payment_methods` WRITE;
/*!40000 ALTER TABLE `payment_methods` DISABLE KEYS */;
INSERT INTO `payment_methods` VALUES (4,'NEQUI','active',1,0,1,NULL,NULL);
/*!40000 ALTER TABLE `payment_methods` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `product_categories`
--

DROP TABLE IF EXISTS `product_categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `product_categories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tenant_id` int(11) NOT NULL DEFAULT 1,
  `name` varchar(255) NOT NULL,
  `description` text DEFAULT NULL,
  `sort_order` int(11) NOT NULL DEFAULT 0,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_product_categories_tenant` (`tenant_id`),
  KEY `idx_product_categories_active` (`is_active`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `product_categories`
--

LOCK TABLES `product_categories` WRITE;
/*!40000 ALTER TABLE `product_categories` DISABLE KEYS */;
/*!40000 ALTER TABLE `product_categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `products`
--

DROP TABLE IF EXISTS `products`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `products` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tenant_id` int(11) NOT NULL DEFAULT 1,
  `name` varchar(255) NOT NULL,
  `sku` varchar(50) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `current_stock` int(11) DEFAULT 0,
  `minimum_stock` int(11) DEFAULT 0,
  `cost_price` decimal(10,2) DEFAULT 0.00,
  `sale_price` decimal(10,2) DEFAULT 0.00,
  `status` enum('active','inactive') DEFAULT 'active',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_sku_tenant` (`sku`,`tenant_id`),
  KEY `idx_tenant` (`tenant_id`),
  CONSTRAINT `fk_products_tenant` FOREIGN KEY (`tenant_id`) REFERENCES `tenants` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `products`
--

LOCK TABLES `products` WRITE;
/*!40000 ALTER TABLE `products` DISABLE KEYS */;
/*!40000 ALTER TABLE `products` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `purchase_order_items`
--

DROP TABLE IF EXISTS `purchase_order_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `purchase_order_items` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `purchase_order_id` int(10) unsigned NOT NULL,
  `product_id` int(10) unsigned NOT NULL,
  `quantity` decimal(12,2) NOT NULL DEFAULT 0.00,
  `unit_cost` decimal(12,2) NOT NULL DEFAULT 0.00,
  `subtotal` decimal(12,2) NOT NULL DEFAULT 0.00,
  PRIMARY KEY (`id`),
  KEY `idx_po_id` (`purchase_order_id`),
  KEY `idx_product_id` (`product_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `purchase_order_items`
--

LOCK TABLES `purchase_order_items` WRITE;
/*!40000 ALTER TABLE `purchase_order_items` DISABLE KEYS */;
/*!40000 ALTER TABLE `purchase_order_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `purchase_orders`
--

DROP TABLE IF EXISTS `purchase_orders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `purchase_orders` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tenant_id` int(11) NOT NULL DEFAULT 1,
  `po_number` varchar(50) NOT NULL,
  `supplier_id` int(11) NOT NULL,
  `order_date` date NOT NULL,
  `expected_date` date DEFAULT NULL,
  `payment_method` varchar(50) DEFAULT NULL,
  `payment_terms` varchar(50) DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `total_amount` decimal(10,2) NOT NULL DEFAULT 0.00,
  `payment_status` enum('pending','partially_paid','paid') NOT NULL DEFAULT 'pending',
  `status` enum('draft','sent','received','cancelled') NOT NULL DEFAULT 'draft',
  `created_by` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_po_number` (`po_number`),
  KEY `idx_purchase_orders_tenant` (`tenant_id`),
  KEY `idx_purchase_orders_supplier` (`supplier_id`),
  KEY `idx_purchase_orders_payment_status` (`payment_status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `purchase_orders`
--

LOCK TABLES `purchase_orders` WRITE;
/*!40000 ALTER TABLE `purchase_orders` DISABLE KEYS */;
/*!40000 ALTER TABLE `purchase_orders` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `purchase_receipt_items`
--

DROP TABLE IF EXISTS `purchase_receipt_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `purchase_receipt_items` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `receipt_id` int(10) unsigned NOT NULL,
  `product_id` int(10) unsigned NOT NULL,
  `quantity` decimal(12,2) NOT NULL DEFAULT 0.00,
  `unit_cost` decimal(12,2) NOT NULL DEFAULT 0.00,
  `subtotal` decimal(12,2) NOT NULL DEFAULT 0.00,
  PRIMARY KEY (`id`),
  KEY `idx_receipt_id` (`receipt_id`),
  KEY `idx_product_id` (`product_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `purchase_receipt_items`
--

LOCK TABLES `purchase_receipt_items` WRITE;
/*!40000 ALTER TABLE `purchase_receipt_items` DISABLE KEYS */;
/*!40000 ALTER TABLE `purchase_receipt_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `purchase_receipts`
--

DROP TABLE IF EXISTS `purchase_receipts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `purchase_receipts` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `receipt_number` varchar(50) NOT NULL,
  `purchase_order_id` int(10) unsigned NOT NULL,
  `supplier_id` int(10) unsigned NOT NULL,
  `received_date` date NOT NULL,
  `notes` text DEFAULT NULL,
  `total_amount` decimal(12,2) NOT NULL DEFAULT 0.00,
  `created_by` int(10) unsigned DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_receipt_number` (`receipt_number`),
  KEY `idx_po_id` (`purchase_order_id`),
  KEY `idx_created_at` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `purchase_receipts`
--

LOCK TABLES `purchase_receipts` WRITE;
/*!40000 ALTER TABLE `purchase_receipts` DISABLE KEYS */;
/*!40000 ALTER TABLE `purchase_receipts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `services`
--

DROP TABLE IF EXISTS `services`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `services` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tenant_id` int(11) NOT NULL DEFAULT 1,
  `name` varchar(100) NOT NULL,
  `description` text DEFAULT NULL,
  `base_price` decimal(10,2) DEFAULT NULL,
  `device_category_id` int(11) DEFAULT NULL,
  `estimated_time` int(11) DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `active` tinyint(1) DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `device_category_id` (`device_category_id`),
  KEY `idx_tenant` (`tenant_id`),
  CONSTRAINT `fk_services_tenant` FOREIGN KEY (`tenant_id`) REFERENCES `tenants` (`id`) ON DELETE CASCADE,
  CONSTRAINT `services_ibfk_1` FOREIGN KEY (`device_category_id`) REFERENCES `device_types` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `services`
--

LOCK TABLES `services` WRITE;
/*!40000 ALTER TABLE `services` DISABLE KEYS */;
/*!40000 ALTER TABLE `services` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `supplier_payments`
--

DROP TABLE IF EXISTS `supplier_payments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `supplier_payments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tenant_id` int(11) NOT NULL DEFAULT 1,
  `supplier_id` int(11) NOT NULL,
  `purchase_order_id` int(11) DEFAULT NULL,
  `payment_amount` decimal(10,2) NOT NULL,
  `amount` decimal(12,2) NOT NULL DEFAULT 0.00,
  `paid_amount` decimal(12,2) NOT NULL DEFAULT 0.00,
  `payment_method` varchar(50) NOT NULL,
  `payment_date` date NOT NULL,
  `reference_number` varchar(100) DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `cash_session_id` int(11) DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `request_id` varchar(64) DEFAULT NULL,
  `status` enum('active','voided') NOT NULL DEFAULT 'active',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_supplier_payments_request` (`request_id`),
  KEY `idx_supplier_payments_tenant` (`tenant_id`),
  KEY `idx_supplier_payments_supplier` (`supplier_id`),
  KEY `idx_supplier_payments_po` (`purchase_order_id`),
  KEY `idx_supplier_payments_status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `supplier_payments`
--

LOCK TABLES `supplier_payments` WRITE;
/*!40000 ALTER TABLE `supplier_payments` DISABLE KEYS */;
/*!40000 ALTER TABLE `supplier_payments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `suppliers`
--

DROP TABLE IF EXISTS `suppliers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `suppliers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tenant_id` int(11) NOT NULL DEFAULT 1,
  `supplier_code` varchar(50) DEFAULT NULL,
  `supplier_type` enum('company','individual') NOT NULL DEFAULT 'company',
  `company_name` varchar(255) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `contact_name` varchar(255) DEFAULT NULL,
  `tax_id` varchar(50) DEFAULT NULL,
  `document_type` enum('cc','nit','ce','passport') DEFAULT NULL,
  `document_number` varchar(50) DEFAULT NULL,
  `phone` varchar(50) DEFAULT NULL,
  `mobile` varchar(50) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `website` varchar(255) DEFAULT NULL,
  `address` text DEFAULT NULL,
  `city` varchar(100) DEFAULT NULL,
  `state` varchar(100) DEFAULT NULL,
  `country` varchar(100) DEFAULT NULL,
  `postal_code` varchar(20) DEFAULT NULL,
  `payment_terms` varchar(50) NOT NULL DEFAULT 'net30',
  `credit_limit` decimal(10,2) DEFAULT NULL,
  `discount_percentage` decimal(5,2) DEFAULT 0.00,
  `bank_name` varchar(255) DEFAULT NULL,
  `account_number` varchar(100) DEFAULT NULL,
  `account_type` enum('checking','savings') DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `rating` tinyint(1) DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_supplier_code` (`supplier_code`),
  KEY `idx_suppliers_tenant` (`tenant_id`),
  KEY `idx_suppliers_company_name` (`company_name`),
  KEY `idx_suppliers_active` (`is_active`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `suppliers`
--

LOCK TABLES `suppliers` WRITE;
/*!40000 ALTER TABLE `suppliers` DISABLE KEYS */;
/*!40000 ALTER TABLE `suppliers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `system_config`
--

DROP TABLE IF EXISTS `system_config`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `system_config` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tenant_id` int(11) NOT NULL DEFAULT 1,
  `config_key` varchar(255) DEFAULT NULL,
  `config_value` text DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_config_tenant` (`config_key`,`tenant_id`),
  UNIQUE KEY `uq_system_config_config_key_tenant` (`config_key`,`tenant_id`),
  KEY `idx_tenant` (`tenant_id`),
  CONSTRAINT `fk_system_config_tenant` FOREIGN KEY (`tenant_id`) REFERENCES `tenants` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=52 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `system_config`
--

LOCK TABLES `system_config` WRITE;
/*!40000 ALTER TABLE `system_config` DISABLE KEYS */;
INSERT INTO `system_config` VALUES (1,1,'backup_mysqldump_path','',NULL,'2026-04-20 04:43:48'),(2,1,'backup_mysql_path','',NULL,'2026-04-20 04:43:48'),(3,1,'backup_include_triggers','0',NULL,'2026-04-20 04:43:48'),(4,1,'backup_include_routines','0',NULL,'2026-04-20 04:43:48'),(5,1,'backup_include_events','0',NULL,'2026-04-20 04:43:48'),(6,1,'backup_retention_zip_count','10',NULL,'2026-04-20 04:43:48'),(7,1,'backup_retention_sql_count','5',NULL,'2026-04-20 04:43:48'),(8,1,'gdrive_client_id','',NULL,'2026-04-20 04:43:48'),(9,1,'gdrive_client_secret','',NULL,'2026-04-20 04:43:48'),(10,1,'gdrive_refresh_token','',NULL,'2026-04-20 04:43:48'),(11,1,'cloud_backup_enabled','0',NULL,'2026-04-20 04:43:48'),(12,1,'order_next_number','1',NULL,'2026-04-20 04:43:48'),(13,1,'invoice_next_number','00002',NULL,'2026-04-25 03:33:02'),(14,1,'warranty_text','garantía de 3 meses según Ley 1480 de 2011. Aplica únicamente sobre la reparación electrónica realizada. No cubre mal uso, humedad, software, virus o intervención de terceros.',NULL,'2026-04-20 04:43:48'),(15,1,'warranty_disclaimers','Daños causados por mal uso, negligencia o manipulación indebida del equipo.\r\nDaños ocasionados por humedad, líquidos, corrosión u oxidación.\r\nSobrecargas eléctricas, variaciones de voltaje, descargas eléctricas o uso de cargadores no originales.\r\nFallas relacionadas con software, sistemas operativos, programas, virus, malware o configuraciones.\r\nEquipos intervenidos, abiertos o reparados por terceros no autorizados después del servicio.\r\nDaños en partes o componentes no reparados ni reemplazados por el servicio técnico.',NULL,'2026-04-20 04:43:48'),(16,1,'warranty_days','90',NULL,'2026-04-20 04:43:48'),(17,1,'abandon_days','90',NULL,'2026-04-20 04:43:48'),(18,1,'smtp_host','smtp.hostinger.com',NULL,'2026-04-20 04:43:48'),(19,1,'smtp_port','587',NULL,'2026-04-20 04:43:48'),(20,1,'smtp_encryption','tls',NULL,'2026-04-20 04:43:48'),(21,1,'smtp_user','no-reply@mycore.com.co',NULL,'2026-04-20 04:43:48'),(22,1,'smtp_pass','99jeissonMY.',NULL,'2026-04-20 04:43:48'),(23,1,'smtp_from_email','no-reply@mycore.com.co',NULL,'2026-04-20 04:43:48'),(24,1,'smtp_from_name','CORE',NULL,'2026-04-20 04:43:48'),(25,1,'smtp_debug','0',NULL,'2026-04-20 04:43:48'),(26,1,'email_tpl_password_reset_preheader','',NULL,'2026-04-20 04:43:48'),(27,1,'email_tpl_welcome_preheader','',NULL,'2026-04-20 04:43:48'),(28,1,'email_tpl_notification_preheader','',NULL,'2026-04-20 04:43:48'),(29,1,'email_brand_logo_enabled','0',NULL,'2026-04-20 04:43:48'),(30,1,'base_tenant_id','1',NULL,'2026-04-20 04:43:48'),(31,1,'currency','COP',NULL,'2026-04-20 04:43:48'),(32,1,'currency_symbol','$',NULL,'2026-04-20 04:43:48'),(33,1,'currency_name','',NULL,'2026-04-20 04:43:48'),(34,1,'phone_prefix','+57',NULL,'2026-04-20 04:43:48'),(35,1,'phone_country','Colombia',NULL,'2026-04-20 04:43:48'),(36,1,'timezone','America/Bogota',NULL,'2026-04-20 04:43:48'),(37,1,'time_format','12',NULL,'2026-04-20 04:43:48'),(38,1,'date_format','d/m/Y',NULL,'2026-04-20 04:43:48'),(39,1,'order_prefix','',NULL,'2026-04-20 04:43:48'),(40,1,'tax_enabled','0',NULL,'2026-04-20 04:43:48'),(41,1,'tax_name','IVA',NULL,'2026-04-20 04:43:48'),(42,1,'tax_rate','19',NULL,'2026-04-20 04:43:48'),(43,1,'datetime_format','d/m/Y H:i A',NULL,'2026-04-20 04:43:48'),(44,1,'order_dashboard_cards','[]',NULL,'2026-04-20 04:43:48'),(45,1,'order_dashboard_excluded_for_total','[\"completado\",\"entregado\",\"cancelado\"]',NULL,'2026-04-20 04:43:48'),(46,1,'theme_mode','light',NULL,'2026-04-20 04:43:48'),(47,1,'theme_color','black',NULL,'2026-04-20 04:43:48'),(48,1,'whatsapp_template_reception','📝 Recepción de equipo\r\n👤 {{cliente}} | ☎️ {{cliente_tel}}\r\n📱 Tipo: {{tipo}}\r\n🏗️ Marca: {{marca}} | Modelo: {{modelo}}\r\n🔢 SN/IMEI: {{sn}}\r\n⚠️ Problema reportado: {{falla}}\r\n🎒 Accesorios: {{accesorios}}\r\n💵 Abono: {{abono}}\r\n💰 Costo aproximado: {{valor}}\r\n🧾 Orden #{{orden}}\r\n🔗 Seguimiento: {{url_seguimiento}}',NULL,'2026-04-20 04:43:48'),(49,1,'whatsapp_template_ready','✅ Equipo listo\r\n👤 {{cliente}}\r\n📱 Tipo: {{tipo}}\r\n🏗️ {{marca}} {{modelo}} (SN {{sn}})\r\n🧾 Orden #{{orden}}\r\n⚠️ Problema: {{falla}}\r\n🔬 Diagnóstico: {{diagnostico}}\r\n🛠️ Solución: {{solucion}}\r\n🎒 Accesorios: {{accesorios}}\r\n💰 Total: {{total}} | 💳 Saldo: {{saldo}}\r\n📍 Retiro: {{fecha_entrega}}\r\n☎️ {{taller_nombre}} | {{taller_tel}}',NULL,'2026-04-20 04:43:48'),(50,1,'whatsapp_template_delivery','📦 Entrega realizada\r\n👤 {{cliente}}\r\n📱 Tipo: {{tipo}}\r\n🏗️ {{marca}} {{modelo}} (SN {{sn}})\r\n🧾 Orden #{{orden}}\r\n🔬 Diagnóstico: {{diagnostico}}\r\n🛠️ Solución: {{solucion}}\r\n🎒 Accesorios: {{accesorios}}\r\n🙏 Gracias por confiar en nosotros\r\n☎️ {{taller_nombre}} | {{taller_tel}}',NULL,'2026-04-20 04:43:48'),(51,1,'whatsapp_template_sale','🧾 Comprobante de Venta #{{factura}}\r\n👤 {{cliente}}\r\n🛍️ Detalles: {{detalles}}\r\n💰 Total: {{total}} | 💳 Saldo: {{saldo}}\r\n🙏 ¡Gracias por tu compra!\r\n☎️ {{taller_nombre}} | {{taller_tel}}',NULL,'2026-04-20 04:43:48');
/*!40000 ALTER TABLE `system_config` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `technical_reports`
--

DROP TABLE IF EXISTS `technical_reports`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `technical_reports` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `order_id` int(11) NOT NULL,
  `report_title` varchar(255) DEFAULT 'Informe Técnico',
  `introduction` text DEFAULT NULL,
  `diagnosis` text DEFAULT NULL,
  `procedure_taken` text DEFAULT NULL,
  `conclusion` text DEFAULT NULL,
  `photos_json` text DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `created_at` datetime DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `tenant_id` int(11) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`),
  KEY `order_id` (`order_id`),
  KEY `idx_technical_reports_tenant` (`tenant_id`),
  CONSTRAINT `technical_reports_ibfk_1` FOREIGN KEY (`order_id`) REFERENCES `work_orders` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `technical_reports`
--

LOCK TABLES `technical_reports` WRITE;
/*!40000 ALTER TABLE `technical_reports` DISABLE KEYS */;
/*!40000 ALTER TABLE `technical_reports` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `template_elements`
--

DROP TABLE IF EXISTS `template_elements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `template_elements` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `template_id` int(11) NOT NULL,
  `element_type` enum('text','image','table','field','line','rectangle','signature') NOT NULL,
  `element_data` longtext NOT NULL CHECK (json_valid(`element_data`)),
  `position_x` decimal(10,2) NOT NULL DEFAULT 0.00,
  `position_y` decimal(10,2) NOT NULL DEFAULT 0.00,
  `width` decimal(10,2) NOT NULL DEFAULT 100.00,
  `height` decimal(10,2) NOT NULL DEFAULT 20.00,
  `z_index` int(11) NOT NULL DEFAULT 1,
  `is_visible` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_template_id` (`template_id`),
  KEY `idx_element_type` (`element_type`),
  KEY `idx_position` (`position_x`,`position_y`),
  CONSTRAINT `template_elements_ibfk_1` FOREIGN KEY (`template_id`) REFERENCES `document_templates` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `template_elements`
--

LOCK TABLES `template_elements` WRITE;
/*!40000 ALTER TABLE `template_elements` DISABLE KEYS */;
/*!40000 ALTER TABLE `template_elements` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tenant_counters`
--

DROP TABLE IF EXISTS `tenant_counters`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tenant_counters` (
  `tenant_id` int(11) NOT NULL,
  `entity` varchar(64) NOT NULL,
  `counter` int(11) NOT NULL DEFAULT 0,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`tenant_id`,`entity`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tenant_counters`
--

LOCK TABLES `tenant_counters` WRITE;
/*!40000 ALTER TABLE `tenant_counters` DISABLE KEYS */;
INSERT INTO `tenant_counters` VALUES (1,'clients',0,'2026-09-02 23:29:17'),(1,'invoices',0,'2026-04-25 00:20:25'),(1,'orders',0,'2026-08-31 21:35:18'),(1,'products',0,'2026-09-02 23:29:17'),(1,'purchase_orders',0,'2026-09-02 23:29:17'),(1,'purchase_receipts',0,'2026-09-02 23:29:17'),(1,'quotes',0,'2026-09-02 23:29:17'),(1,'sales',0,'2026-09-02 23:29:17'),(1,'services',0,'2026-09-02 23:29:17'),(1,'technical_reports',0,'2026-09-02 23:29:17');
/*!40000 ALTER TABLE `tenant_counters` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tenants`
--

DROP TABLE IF EXISTS `tenants`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tenants` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `company_name` varchar(255) NOT NULL,
  `slug` varchar(64) NOT NULL,
  `status` enum('active','suspended') DEFAULT 'active',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `slug` (`slug`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tenants`
--

LOCK TABLES `tenants` WRITE;
/*!40000 ALTER TABLE `tenants` DISABLE KEYS */;
INSERT INTO `tenants` VALUES (1,'Empresa_Base','default','active','2026-04-18 03:25:58','2026-04-18 03:25:59');
/*!40000 ALTER TABLE `tenants` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `transaction_categories`
--

DROP TABLE IF EXISTS `transaction_categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `transaction_categories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `type` enum('income','expense') NOT NULL,
  `description` text DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `transaction_categories`
--

LOCK TABLES `transaction_categories` WRITE;
/*!40000 ALTER TABLE `transaction_categories` DISABLE KEYS */;
/*!40000 ALTER TABLE `transaction_categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_notes`
--

DROP TABLE IF EXISTS `user_notes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_notes` (
  `user_id` int(11) NOT NULL,
  `content` text DEFAULT NULL,
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_notes`
--

LOCK TABLES `user_notes` WRITE;
/*!40000 ALTER TABLE `user_notes` DISABLE KEYS */;
/*!40000 ALTER TABLE `user_notes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_notifications`
--

DROP TABLE IF EXISTS `user_notifications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_notifications` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `notification_id` int(11) NOT NULL,
  `is_read` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `user_id` int(11) NOT NULL,
  `read_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_user_read` (`user_id`,`is_read`),
  KEY `idx_notification_id` (`notification_id`),
  CONSTRAINT `fk_un_n2` FOREIGN KEY (`notification_id`) REFERENCES `notifications` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_notifications`
--

LOCK TABLES `user_notifications` WRITE;
/*!40000 ALTER TABLE `user_notifications` DISABLE KEYS */;
/*!40000 ALTER TABLE `user_notifications` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tenant_id` int(11) NOT NULL DEFAULT 1,
  `name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `photo` varchar(255) DEFAULT NULL,
  `password` varchar(255) NOT NULL,
  `role` enum('admin','technician','user') DEFAULT 'user',
  `active` tinyint(1) DEFAULT 1,
  `reset_token` varchar(255) DEFAULT NULL,
  `reset_expires` datetime DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`),
  KEY `idx_users_tenant` (`tenant_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,1,'Administrador','admin@core.com',NULL,'$2b$10$rKMk1vQ5bf2NqsaTTV8ROOXra91t2FCi74HCoCYaQcuWPv6qG1THe','admin',1,NULL,NULL,'2026-04-18 03:25:59','2026-09-02 05:13:39');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `whatsapp_templates`
--

DROP TABLE IF EXISTS `whatsapp_templates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `whatsapp_templates` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `type` enum('notification','status_update','reminder','custom') NOT NULL,
  `subject` varchar(200) DEFAULT NULL,
  `message` text NOT NULL,
  `variables` longtext DEFAULT NULL CHECK (json_valid(`variables`)),
  `is_default` tinyint(1) NOT NULL DEFAULT 0,
  `status` enum('active','inactive') NOT NULL DEFAULT 'active',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_name` (`name`),
  KEY `idx_type` (`type`),
  KEY `idx_is_default` (`is_default`),
  KEY `idx_status` (`status`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `whatsapp_templates`
--

LOCK TABLES `whatsapp_templates` WRITE;
/*!40000 ALTER TABLE `whatsapp_templates` DISABLE KEYS */;
INSERT INTO `whatsapp_templates` VALUES (1,'Nueva Orden','notification','Orden Recibida - {{order_number}}','Hola {{client_name}}, hemos recibido tu equipo {{device_model}} para revisión. Tu número de orden es {{order_number}}. Te notificaremos cualquier novedad.','[\"{{client_name}}\",\"{{order_number}}\",\"{{device_model}}\"]',1,'active','2026-02-03 16:12:15','2026-04-20 04:44:11'),(2,'Nueva Venta','notification','Comprobante de Venta - {{sale_number}}','Hola {{client_name}}, gracias por tu compra. Adjuntamos el comprobante de tu venta #{{sale_number}} por un total de {{total_amount}}.','[\"{{client_name}}\",\"{{sale_number}}\",\"{{total_amount}}\"]',1,'active','2026-02-03 16:12:15','2026-04-20 04:44:11'),(3,'Orden Finalizada','status_update','Orden Lista - {{order_number}}','Hola {{client_name}}, tu equipo {{device_model}} (Orden: {{order_number}}) está listo para ser retirado. El total a pagar es {{total_amount}}.','[\"{{client_name}}\",\"{{order_number}}\",\"{{device_model}}\",\"{{total_amount}}\"]',1,'active','2026-02-03 16:12:15','2026-04-20 04:44:11');
/*!40000 ALTER TABLE `whatsapp_templates` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `work_order_services`
--

DROP TABLE IF EXISTS `work_order_services`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `work_order_services` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `work_order_id` int(11) NOT NULL,
  `service_id` int(11) NOT NULL,
  `quantity` decimal(12,2) NOT NULL DEFAULT 1.00,
  `service_price` decimal(12,2) NOT NULL DEFAULT 0.00,
  `total_price` decimal(12,2) NOT NULL DEFAULT 0.00,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_order_id` (`work_order_id`),
  KEY `idx_service_id` (`service_id`),
  KEY `idx_created_at` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `work_order_services`
--

LOCK TABLES `work_order_services` WRITE;
/*!40000 ALTER TABLE `work_order_services` DISABLE KEYS */;
/*!40000 ALTER TABLE `work_order_services` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `work_orders`
--

DROP TABLE IF EXISTS `work_orders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `work_orders` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `order_number` varchar(64) DEFAULT NULL,
  `verification_code` varchar(16) DEFAULT NULL,
  `tenant_id` int(11) NOT NULL DEFAULT 1,
  `client_id` int(11) NOT NULL,
  `device_type_id` int(11) DEFAULT NULL,
  `device_category_id` int(11) DEFAULT NULL,
  `device_brand` varchar(100) DEFAULT NULL,
  `device_model` varchar(100) DEFAULT NULL,
  `device_password` varchar(255) DEFAULT NULL,
  `serial_number` varchar(100) DEFAULT NULL,
  `reported_issue` text NOT NULL,
  `client_observations` text DEFAULT NULL,
  `device_photo` text DEFAULT NULL,
  `diagnosis` text DEFAULT NULL,
  `solution` text DEFAULT NULL,
  `status` varchar(64) NOT NULL DEFAULT 'pending',
  `priority` enum('low','medium','high','urgent') DEFAULT 'medium',
  `estimated_cost` decimal(10,2) DEFAULT NULL,
  `advance_payment` decimal(10,2) DEFAULT 0.00,
  `payment_method` varchar(50) DEFAULT NULL,
  `payment_reference` varchar(255) DEFAULT NULL,
  `final_cost` decimal(10,2) DEFAULT NULL,
  `technician_notes` text DEFAULT NULL,
  `received_date` timestamp NOT NULL DEFAULT current_timestamp(),
  `estimated_completion` date DEFAULT NULL,
  `completed_date` timestamp NULL DEFAULT NULL,
  `delivered_date` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `delivery_payment` decimal(10,2) DEFAULT 0.00,
  `approval_status` varchar(20) NOT NULL DEFAULT 'none',
  `approval_signature_path` varchar(255) DEFAULT NULL,
  `approved_at` datetime DEFAULT NULL,
  `approved_quote_amount` decimal(10,2) DEFAULT NULL,
  `approval_comment` text DEFAULT NULL,
  `approval_signature` text DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_order_tenant` (`order_number`,`tenant_id`),
  KEY `client_id` (`client_id`),
  KEY `device_category_id` (`device_category_id`),
  KEY `work_orders_ibfk_device_type` (`device_type_id`),
  KEY `idx_tenant` (`tenant_id`),
  CONSTRAINT `fk_work_orders_tenant` FOREIGN KEY (`tenant_id`) REFERENCES `tenants` (`id`) ON DELETE CASCADE,
  CONSTRAINT `work_orders_ibfk_1` FOREIGN KEY (`client_id`) REFERENCES `clients` (`id`),
  CONSTRAINT `work_orders_ibfk_2` FOREIGN KEY (`device_category_id`) REFERENCES `device_types` (`id`),
  CONSTRAINT `work_orders_ibfk_device_type` FOREIGN KEY (`device_type_id`) REFERENCES `device_types` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `work_orders`
--

LOCK TABLES `work_orders` WRITE;
/*!40000 ALTER TABLE `work_orders` DISABLE KEYS */;
/*!40000 ALTER TABLE `work_orders` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping routines for database 'core_tenant_000001'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-09-03  0:52:03
