-- MariaDB dump 10.19  Distrib 10.4.32-MariaDB, for Win64 (AMD64)
--
-- Host: 127.0.0.1    Database: core_master
-- ------------------------------------------------------
-- Server version	10.4.32-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Current Database: `core_master`
--

/*!40000 DROP DATABASE IF EXISTS `core_master`*/;

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `core_master` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish_ci */;

USE `core_master`;

--
-- Table structure for table `empresas`
--

DROP TABLE IF EXISTS `empresas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `empresas` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `nombre` varchar(255) NOT NULL,
  `estado` enum('active','suspended','deleted','provisioning') NOT NULL DEFAULT 'active',
  `db_host` varchar(255) NOT NULL,
  `db_port` int(10) unsigned NOT NULL DEFAULT 3306,
  `db_name` varchar(255) NOT NULL,
  `db_user` varchar(255) NOT NULL,
  `db_password_enc` text NOT NULL,
  `db_password_iv` varchar(255) NOT NULL,
  `db_password_tag` varchar(255) NOT NULL,
  `schema_version` int(10) unsigned NOT NULL DEFAULT 1,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_empresas_db_name` (`db_name`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `empresas`
--

LOCK TABLES `empresas` WRITE;
/*!40000 ALTER TABLE `empresas` DISABLE KEYS */;
INSERT INTO `empresas` VALUES (1,'Empresa_Base','active','localhost',3306,'core_tenant_000001','root','','','',1,'2026-04-17 22:16:23','2026-09-01 00:45:41');
/*!40000 ALTER TABLE `empresas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `licencias`
--

DROP TABLE IF EXISTS `licencias`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `licencias` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `codigo` varchar(64) NOT NULL,
  `plan` varchar(50) NOT NULL DEFAULT 'standard',
  `estado` enum('disponible','usada','revocada') NOT NULL DEFAULT 'disponible',
  `empresa_id` int(10) unsigned DEFAULT NULL,
  `used_at` datetime DEFAULT NULL,
  `expires_at` datetime DEFAULT NULL,
  `valid_days` int(11) DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_licencias_codigo` (`codigo`),
  KEY `idx_licencias_empresa` (`empresa_id`),
  CONSTRAINT `fk_licencias_empresa` FOREIGN KEY (`empresa_id`) REFERENCES `empresas` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `licencias`
--

LOCK TABLES `licencias` WRITE;
/*!40000 ALTER TABLE `licencias` DISABLE KEYS */;
INSERT INTO `licencias` VALUES (1,'AFRB-VF83-D9BM','standard','disponible',NULL,NULL,NULL,NULL,'2026-04-22 20:32:14','2026-07-21 22:04:55'),(3,'8FPN-U8S5-KGBX','standard','usada',1,'2026-05-01 17:52:54',NULL,NULL,'2026-04-22 20:32:18','2026-05-01 17:52:54'),(4,'NDT4-QPKV-T88S','standard','disponible',NULL,NULL,NULL,NULL,'2026-05-01 17:54:44','2026-07-21 22:04:55'),(5,'XTR2-ENBH-28VK','standard','disponible',NULL,NULL,NULL,NULL,'2026-05-01 17:54:46','2026-07-21 22:04:55'),(6,'UBP6-8LBL-G2J2','standard','disponible',NULL,NULL,NULL,NULL,'2026-05-01 17:54:47','2026-07-21 22:04:55'),(7,'QUXA-YDLA-TRBU','standard','disponible',NULL,NULL,NULL,NULL,'2026-05-01 18:24:31','2026-07-21 22:04:55'),(8,'BQ8S-UP3M-3MD5','trial','disponible',NULL,NULL,'2026-07-28 21:59:12',7,'2026-07-21 21:59:12','2026-07-21 21:59:12'),(10,'65CD-7CU4-UK4M','standard','disponible',NULL,NULL,NULL,NULL,'2026-07-21 21:59:19','2026-07-21 21:59:19');
/*!40000 ALTER TABLE `licencias` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `login_attempts`
--

DROP TABLE IF EXISTS `login_attempts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `login_attempts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ip_address` varchar(45) NOT NULL,
  `email` varchar(255) DEFAULT NULL,
  `success` tinyint(1) NOT NULL DEFAULT 0,
  `attempt_time` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `ip_address` (`ip_address`),
  KEY `attempt_time` (`attempt_time`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `login_attempts`
--

LOCK TABLES `login_attempts` WRITE;
/*!40000 ALTER TABLE `login_attempts` DISABLE KEYS */;
/*!40000 ALTER TABLE `login_attempts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `saas_password_resets`
--

DROP TABLE IF EXISTS `saas_password_resets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `saas_password_resets` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `email` varchar(255) NOT NULL,
  `tenant_id` int(11) NOT NULL DEFAULT 1,
  `token` varchar(255) NOT NULL,
  `expires_at` datetime NOT NULL,
  `created_at` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_token` (`token`),
  KEY `idx_email` (`email`),
  KEY `idx_tenant_id` (`tenant_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `saas_password_resets`
--

LOCK TABLES `saas_password_resets` WRITE;
/*!40000 ALTER TABLE `saas_password_resets` DISABLE KEYS */;
INSERT INTO `saas_password_resets` VALUES (1,'jeissonandroi@gmail.com',2,'c06b49058ec1853a35a446e917a8ced0d3c12b0c1770c58044f7dab837d8a98c','2026-06-14 16:57:05','2026-06-14 15:57:05');
/*!40000 ALTER TABLE `saas_password_resets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `saas_settings`
--

DROP TABLE IF EXISTS `saas_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `saas_settings` (
  `setting_key` varchar(128) NOT NULL,
  `setting_value` text DEFAULT NULL,
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`setting_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `saas_settings`
--

LOCK TABLES `saas_settings` WRITE;
/*!40000 ALTER TABLE `saas_settings` DISABLE KEYS */;
/*!40000 ALTER TABLE `saas_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `saas_super_admins`
--

DROP TABLE IF EXISTS `saas_super_admins`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `saas_super_admins` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(64) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `twofa_secret` varchar(255) DEFAULT NULL,
  `backup_pin` varchar(255) DEFAULT NULL,
  `trusted_ips` text DEFAULT NULL,
  `mfa_preference` enum('totp','email','pin') DEFAULT 'totp',
  `recovery_token` varchar(255) DEFAULT NULL,
  `recovery_expires` datetime DEFAULT NULL,
  `created_at` datetime DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `saas_super_admins`
--

LOCK TABLES `saas_super_admins` WRITE;
/*!40000 ALTER TABLE `saas_super_admins` DISABLE KEYS */;
INSERT INTO `saas_super_admins` VALUES (2,'jeisson','jeissonandro@gmail.com','$2b$10$x/Gghx4dItzSRaS/jisW4.SdhNV0./BjezAZ8Y9in2nEO9eRpKs26',NULL,NULL,NULL,'totp',NULL,NULL,'2026-09-02 00:44:49','2026-09-02 00:45:38');
/*!40000 ALTER TABLE `saas_super_admins` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `saas_users_lookup`
--

DROP TABLE IF EXISTS `saas_users_lookup`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `saas_users_lookup` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `email` varchar(255) NOT NULL,
  `tenant_id` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`),
  KEY `tenant_id` (`tenant_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `saas_users_lookup`
--

LOCK TABLES `saas_users_lookup` WRITE;
/*!40000 ALTER TABLE `saas_users_lookup` DISABLE KEYS */;
/*!40000 ALTER TABLE `saas_users_lookup` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `signup_attempts`
--

DROP TABLE IF EXISTS `signup_attempts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `signup_attempts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ip_address` varchar(45) NOT NULL,
  `email` varchar(255) DEFAULT NULL,
  `success` tinyint(1) NOT NULL DEFAULT 0,
  `attempt_time` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `ip_address` (`ip_address`),
  KEY `attempt_time` (`attempt_time`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `signup_attempts`
--

LOCK TABLES `signup_attempts` WRITE;
/*!40000 ALTER TABLE `signup_attempts` DISABLE KEYS */;
INSERT INTO `signup_attempts` VALUES (1,'::1','admin2@core.com',0,'2026-05-02 00:04:20'),(2,'::1','admin2@core.com',0,'2026-05-02 00:04:58'),(3,'::1','admin22@core.com',1,'2026-05-02 00:05:25');
/*!40000 ALTER TABLE `signup_attempts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `super_admin_feedback`
--

DROP TABLE IF EXISTS `super_admin_feedback`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `super_admin_feedback` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `empresa_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `user_name` varchar(255) NOT NULL,
  `user_email` varchar(255) NOT NULL,
  `tenant_name` varchar(255) NOT NULL,
  `type` varchar(16) NOT NULL,
  `priority` varchar(16) NOT NULL DEFAULT 'MEDIA',
  `subject` varchar(255) NOT NULL,
  `message` text NOT NULL,
  `context_url` varchar(500) DEFAULT NULL,
  `context_user_agent` text DEFAULT NULL,
  `attachments_json` text DEFAULT NULL,
  `status` varchar(16) NOT NULL DEFAULT 'PENDIENTE',
  `admin_note` text DEFAULT NULL,
  `reviewed_by_id` int(11) DEFAULT NULL,
  `reviewed_by_name` varchar(255) DEFAULT NULL,
  `reviewed_at` datetime DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_empresa` (`empresa_id`),
  KEY `idx_status` (`status`),
  KEY `idx_type` (`type`),
  KEY `idx_priority` (`priority`),
  KEY `idx_created_at` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `super_admin_feedback`
--

LOCK TABLES `super_admin_feedback` WRITE;
/*!40000 ALTER TABLE `super_admin_feedback` DISABLE KEYS */;
/*!40000 ALTER TABLE `super_admin_feedback` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tenant_db_pool`
--

DROP TABLE IF EXISTS `tenant_db_pool`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tenant_db_pool` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `db_host` varchar(255) NOT NULL,
  `db_port` int(10) unsigned NOT NULL DEFAULT 3306,
  `db_name` varchar(255) NOT NULL,
  `db_user` varchar(255) NOT NULL,
  `db_password_enc` text NOT NULL,
  `db_password_iv` varchar(255) NOT NULL,
  `db_password_tag` varchar(255) NOT NULL,
  `status` enum('available','reserved','used','error') NOT NULL DEFAULT 'available',
  `empresa_id` int(10) unsigned DEFAULT NULL,
  `reserved_at` datetime DEFAULT NULL,
  `used_at` datetime DEFAULT NULL,
  `last_error` text DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_tenant_db_pool_db_name` (`db_name`),
  KEY `idx_tenant_db_pool_status` (`status`),
  KEY `idx_tenant_db_pool_empresa` (`empresa_id`),
  CONSTRAINT `fk_tenant_db_pool_empresa` FOREIGN KEY (`empresa_id`) REFERENCES `empresas` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=29 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tenant_db_pool`
--

LOCK TABLES `tenant_db_pool` WRITE;
/*!40000 ALTER TABLE `tenant_db_pool` DISABLE KEYS */;
INSERT INTO `tenant_db_pool` VALUES (1,'localhost',3306,'core_tenant_000001','core_u_000001','QCrr6HcMwbrh6Ssj6o8ocVP9fAmbgNjuhYgu35GG7+w=','nW1zcPxRUvb4SD7f','B7iMiJOzNBNmqVqHyo1i7Q==','used',1,NULL,'2026-05-01 18:19:54',NULL,'2026-05-01 18:19:54','2026-05-01 18:19:54'),(20,'localhost',3306,'core_tenant_000002','core_u_000002','G4AVnPywYA5IJKZuxR6xEdFKzpk=','11eJDCz+T4Tg9uAS','clI/MqUvx4auNKsfy8dRzg==','available',NULL,NULL,NULL,NULL,'2026-09-03 00:44:19','2026-09-03 00:44:19'),(21,'localhost',3306,'core_tenant_000003','core_u_000003','DZBSZ2Gl0Ewr7cmYHrnb6cYEKLk=','mxI87yyb3+FDq5LD','H8BByJnbmwGI/b3/m2gbsA==','available',NULL,NULL,NULL,NULL,'2026-09-03 00:44:19','2026-09-03 00:44:19'),(22,'localhost',3306,'core_tenant_000004','core_u_000004','Pj/obj6xwd3K2wSfd0t5b4xJXFc=','IDIriLWdFsYMEv5n','0Nlj1VSC2itd1+4r3R4Rrg==','available',NULL,NULL,NULL,NULL,'2026-09-03 00:44:19','2026-09-03 00:44:19'),(23,'localhost',3306,'core_tenant_000005','core_u_000005','6mkN0/CYzlaPalcI7poIGKzJalA=','nxtaMrEkRPvoFq4O','FnSIj+iPbyRH4dWp82Vhww==','available',NULL,NULL,NULL,NULL,'2026-09-03 00:44:19','2026-09-03 00:44:19'),(24,'localhost',3306,'core_tenant_000006','core_u_000006','kgQ2VercVuiCIXdH5DBtlORVd60=','TnwoMmbPqQTa0Sly','AWtzvWofnNQ8pBqWuUk9bg==','available',NULL,NULL,NULL,NULL,'2026-09-03 00:44:19','2026-09-03 00:44:19'),(25,'localhost',3306,'core_tenant_000007','core_u_000007','ljR0AkZWu70KDYQQdeQgBCtvB+M=','wrdp4p4jQ22fiZID','pIxAQLJV34Tur+7jdQSRTg==','available',NULL,NULL,NULL,NULL,'2026-09-03 00:44:19','2026-09-03 00:44:19'),(26,'localhost',3306,'core_tenant_000008','core_u_000008','cKkbPVbg3gKYRO0y+AA8osP4vV0=','5UlBiG5QvfPMTEiT','ZsXLGq9q0WmPbmfpi5+2GA==','available',NULL,NULL,NULL,NULL,'2026-09-03 00:44:19','2026-09-03 00:44:19'),(27,'localhost',3306,'core_tenant_000009','core_u_000009','jaowwoXBW0T719SwAwfbEC51Ogg=','cShFOSJik+4zR17/','svqohMJdCY0W/IqV/k0+rA==','available',NULL,NULL,NULL,NULL,'2026-09-03 00:44:19','2026-09-03 00:44:19'),(28,'localhost',3306,'core_tenant_000010','core_u_000010','aS7LmVt69K5sKSXNBWMkoWeTLr8=','2xjlT04pFoCzVleM','IQiTByRmahOw8E146P0C/g==','available',NULL,NULL,NULL,NULL,'2026-09-03 00:44:19','2026-09-03 00:44:19');
/*!40000 ALTER TABLE `tenant_db_pool` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `usuarios_master`
--

DROP TABLE IF EXISTS `usuarios_master`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `usuarios_master` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `empresa_id` int(10) unsigned NOT NULL,
  `email` varchar(255) NOT NULL,
  `password_hash` varchar(255) NOT NULL,
  `rol` varchar(50) NOT NULL DEFAULT 'admin',
  `nombre` varchar(255) NOT NULL DEFAULT '',
  `activo` tinyint(1) NOT NULL DEFAULT 1,
  `ultimo_login_at` datetime DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `photo_url` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_usuarios_master_email` (`email`),
  KEY `idx_usuarios_master_empresa` (`empresa_id`),
  CONSTRAINT `fk_usuarios_master_empresa` FOREIGN KEY (`empresa_id`) REFERENCES `empresas` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `usuarios_master`
--

LOCK TABLES `usuarios_master` WRITE;
/*!40000 ALTER TABLE `usuarios_master` DISABLE KEYS */;
INSERT INTO `usuarios_master` VALUES (1,1,'admin@core.com','$2b$10$rKMk1vQ5bf2NqsaTTV8ROOXra91t2FCi74HCoCYaQcuWPv6qG1THe','admin','Administrador',1,'2026-05-10 23:28:42','2026-04-17 22:25:59','2026-09-02 00:13:39','');
/*!40000 ALTER TABLE `usuarios_master` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping routines for database 'core_master'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-09-03  0:44:19
