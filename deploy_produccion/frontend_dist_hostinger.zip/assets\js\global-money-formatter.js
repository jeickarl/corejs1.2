/* global vanilla money formatting for payment/money inputs
   ============================================================
   Detecta la MONEDA y PAÍS configurados via <html data-currency / data-country / data-locale / data-thousands-sep / data-decimal-sep>
   (el store regional de Pinia publica estos attrs + evento 'regional:changed').

   - Default (sin attrs): es-CO, miles='.', decimal=',', sin centavos
   - USD en en-US: miles=',', decimal='.'
   - EUR en de-DE/es-ES: miles='.', decimal=','
   - Permite decimales si la moneda los usa (USD/EUR sí, COP/ARS/CLP no).

   Actúa sobre inputs con clase 'money-input-esco' O con data-format='money-esco'
   O con clase 'inv-input' + (text-end / inputmode=numeric / decimal / padre con .inv-currency-green)
   ============================================================ */
(function () {
  'use strict'
  var ATTR_INIT = 'data-global-money-init'
  var META_CUR = 'data-currency'
  var META_LOC = 'data-locale'
  var META_THOUSANDS = 'data-thousands-sep'
  var META_DECIMAL = 'data-decimal-sep'
  var META_FRACTIONS = 'data-fraction-digits'

  function readMeta() {
    const root = document.documentElement
    const currency = (root.getAttribute(META_CUR) || 'COP').trim().toUpperCase() || 'COP'
    const locale = (root.getAttribute(META_LOC) || 'es-CO').trim() || 'es-CO'
    let thousandsSep = (root.getAttribute(META_THOUSANDS) || '').trim()
    let decimalSep = (root.getAttribute(META_DECIMAL) || '').trim()
    let fractions = parseInt(root.getAttribute(META_FRACTIONS) || '', 10)
    if (!thousandsSep || !decimalSep) {
      const sampled = sampleSeparators(locale, currency)
      if (!thousandsSep) thousandsSep = sampled.thousandsSep
      if (!decimalSep) decimalSep = sampled.decimalSep
    }
    if (!Number.isFinite(fractions) || isNaN(fractions) || fractions < 0) {
      fractions = defaultFractionDigits(currency)
    }
    return { currency, locale, thousandsSep, decimalSep, fractions }
  }

  function sampleSeparators(locale, currency) {
    try {
      const s = new Intl.NumberFormat(locale, {
        style: 'currency',
        currency: currency || 'COP',
        minimumFractionDigits: 2,
        maximumFractionDigits: 2,
      }).format(1234567.5)
      const mt = s.match(/1(.{1})234/)
      const thousandsSep = (mt && mt[1]) || '.'
      const hasComma = s.includes(',')
      const hasDot = s.includes('.')
      let decimalSep = '.'
      if (thousandsSep === '.' && hasComma) decimalSep = ','
      else if (thousandsSep === ',' && hasDot) decimalSep = '.'
      else if (locale.startsWith('es') || locale === 'pt-BR') decimalSep = ','
      return { thousandsSep, decimalSep }
    } catch (_) {
      return { thousandsSep: '.', decimalSep: ',' }
    }
  }

  function defaultFractionDigits(currency) {
    const noCents = { COP: 1, ARS: 1, VES: 1, CLP: 1, PYG: 1, UYU: 1, CRC: 1, GTQ: 1, HNL: 1, NIO: 1, DOP: 1, BOB: 1 }
    return noCents[(currency || 'COP').toUpperCase()] ? 0 : 2
  }

  function applyMetaToDomIfMissing(meta) {
    try {
      const root = document.documentElement
      if (!root.getAttribute(META_THOUSANDS)) root.setAttribute(META_THOUSANDS, meta.thousandsSep)
      if (!root.getAttribute(META_DECIMAL)) root.setAttribute(META_DECIMAL, meta.decimalSep)
      if (!root.getAttribute(META_FRACTIONS)) root.setAttribute(META_FRACTIONS, String(meta.fractions))
    } catch (_) {}
  }

  function getDigitsOnly(s) {
    return String(s == null ? '' : s).replace(/[^0-9]/g, '')
  }
  function addThousandsSep(digits, sep) {
    if (!digits) return ''
    return digits.replace(/\B(?=(\d{3})+(?!\d))/g, sep || '.')
  }
  function stripThousands(s, sep) {
    return String(s || '').split(sep || '.').join('')
  }
  function isMoneyInput(el) {
    if (!el || el.tagName !== 'INPUT') return false
    if (el.hasAttribute('data-format') && (el.getAttribute('data-format') === 'money-esco' || el.getAttribute('data-format') === 'money')) return true
    if (el.classList && el.classList.contains('money-input-esco')) return true
    if (el.classList && el.classList.contains('inv-input')) {
      if (el.classList.contains('text-end')) return true
      var mode = (el.getAttribute('inputmode') || '').toLowerCase()
      if (mode === 'numeric' || mode === 'decimal') return true
      var parent = el.closest('.inv-input-box')
      if (parent && parent.querySelector('.inv-currency-green')) return true
    }
    var insideCurrencyGroup = (function () {
      var group = el.closest('.on-input-group, .pn-input-group, .pe-input-group, .oe-input-group, .cp-input-group, .sp-input-group, .cs-input-group, .cash-input-group, .bill-input-group, .po-input-group, .pr-input-group, .su-input-group, .se-input-group, .np-input-group, .ep-input-group, .inv-input-box')
      if (!group) return false
      var addon = group.querySelector('.on-addon, .pn-addon, .pe-addon, .oe-addon, .cp-addon, .sp-addon, .cs-addon, .cash-addon, .bill-addon, .po-addon, .pr-addon, .su-addon, .se-addon, .np-addon, .ep-addon, .inv-currency-green, .input-group-addon')
      if (addon && /[$€£¥₡₲₦₱₪₸₮₵₴₫฿₡₢₣₤₥₦₧₨₩₪₫€₭₮₯₰₱₲₳₴₵₶₷₸₹₺₻₼₽₾₿]/.test(addon.textContent || '')) return true
      return false
    })()
    if (el.classList && Array.from(el.classList).some((c) => /^(pn|pe|on|oe|cp|sp|cs|cash|bill|po|pr|su|se|np|ep)[-_]?input/i.test(c))) {
      var type = (el.getAttribute('type') || 'text').toLowerCase()
      if (type === 'number' || type === 'text') {
        if (insideCurrencyGroup) return true
        var mode2 = (el.getAttribute('inputmode') || '').toLowerCase()
        if (mode2 === 'numeric' || mode2 === 'decimal') return true
        var step = el.getAttribute('step')
        if (step && (step === '0.01' || step === '1' || step === '0.1' || step === 'any')) return true
        if (el.name && /(price|amount|total|subtotal|paid|balance|cost|cash|payment|debit|credit|value|stock)/i.test(el.name)) return true
        if (el.id && /(price|amount|total|subtotal|paid|balance|cost|cash|payment|debit|credit|value|stock)/i.test(el.id)) return true
      }
    }
    if (insideCurrencyGroup) return true
    if (el.name && /(price|amount|total|subtotal|paid|balance|cost|cash|payment|debit|credit|value)/i.test(el.name)) return true
    if (el.id && /(price|amount|total|subtotal|paid|balance|cost|cash|payment|debit|credit|value)/i.test(el.id)) return true
    if (el.classList && Array.from(el.classList).some((c) => /(price|amount|total|subtotal|paid|balance|cost|cash|payment|money|currency)/i.test(c))) return true
    return false
  }
  function formatNow(el) {
    if (!isMoneyInput(el)) return { ok: false, changed: false }
    const meta = readMeta()
    applyMetaToDomIfMissing(meta)
    const raw = String(el.value == null ? '' : el.value)
    if (!raw.trim()) {
      if (el.value !== '') { el.value = ''; return { ok: true, changed: true } }
      return { ok: true, changed: false }
    }
    if (meta.fractions <= 0) {
      const digits = getDigitsOnly(raw)
      if (!digits) {
        if (el.value !== '') { el.value = ''; return { ok: true, changed: true } }
        return { ok: true, changed: false }
      }
      const formatted = addThousandsSep(digits, meta.thousandsSep)
      if (el.value !== formatted) { el.value = formatted; return { ok: true, changed: true } }
      return { ok: true, changed: false }
    }
    let intRaw = raw
    let decRaw = ''
    const decIdx = raw.lastIndexOf(meta.decimalSep)
    if (decIdx >= 0) {
      intRaw = raw.slice(0, decIdx)
      decRaw = raw.slice(decIdx + 1)
    } else {
      const altIdx = raw.lastIndexOf(meta.decimalSep === ',' ? '.' : ',')
      if (altIdx >= 0) {
        intRaw = raw.slice(0, altIdx)
        decRaw = raw.slice(altIdx + 1)
      }
    }
    const intDigits = getDigitsOnly(intRaw)
    const decDigits = getDigitsOnly(decRaw).slice(0, meta.fractions)
    const intFmt = addThousandsSep(intDigits, meta.thousandsSep)
    const result = decDigits ? intFmt + meta.decimalSep + decDigits : intFmt
    if (el.value !== result) { el.value = result; return { ok: true, changed: true } }
    return { ok: true, changed: false }
  }
  function dispatchVueInput(el) {
    try {
      if (el && el.getAttribute && el.getAttribute('data-mfmt-dispatch') === '1') return
      if (el && el.setAttribute) el.setAttribute('data-mfmt-dispatch', '1')
      var ev = null
      try { ev = new Event('input', { bubbles: true, cancelable: true }) } catch (_) {
        ev = document.createEvent('Event')
        ev.initEvent('input', true, true)
      }
      if (ev) el.dispatchEvent(ev)
      var ch = null
      try { ch = new Event('change', { bubbles: true, cancelable: true }) } catch (_) {
        ch = document.createEvent('Event')
        ch.initEvent('change', true, true)
      }
      if (ch) setTimeout(function () { try { el.dispatchEvent(ch) } catch (_) {} }, 0)
      setTimeout(function () { try { if (el && el.removeAttribute) el.removeAttribute('data-mfmt-dispatch') } catch (_) {} }, 50)
    } catch (_) {}
  }

  function onInput(evt) {
    const el = evt.target
    if (!isMoneyInput(el)) return
    if (el.getAttribute && el.getAttribute('data-mfmt-dispatch') === '1') {
      return
    }
    const res = formatNow(el)
    if (res.ok) {
      if (res.changed) dispatchVueInput(el)
      setTimeout(function () { moveCaretEnd(el) }, 0)
    }
  }
  function onBlur(evt) {
    const el = evt.target
    if (!isMoneyInput(el)) return
    const res = formatNow(el)
    if (res.changed) dispatchVueInput(el)
  }
  function onPaste(evt) {
    const el = evt.target
    if (!isMoneyInput(el)) return
    setTimeout(function () {
      const res = formatNow(el)
      if (res.changed) dispatchVueInput(el)
      moveCaretEnd(el)
    }, 0)
  }
  function onKeyup(evt) {
    const el = evt.target
    if (!isMoneyInput(el)) return
    const res = formatNow(el)
    if (res.changed) dispatchVueInput(el)
    setTimeout(function () { moveCaretEnd(el) }, 0)
  }
  function onRegionalChanged() {
    try {
      const meta = readMeta()
      applyMetaToDomIfMissing(meta)
      document.querySelectorAll('input').forEach(function (el) {
        if (isMoneyInput(el)) {
          const res = formatNow(el)
          if (res.changed) dispatchVueInput(el)
        }
      })
    } catch (_) {}
  }

  function attachGlobals() {
    if (document.body && document.body.getAttribute(ATTR_INIT)) return
    document.addEventListener('input', onInput, true)
    document.addEventListener('blur', onBlur, true)
    document.addEventListener('paste', onPaste, true)
    document.addEventListener('keyup', onKeyup, true)
    window.addEventListener('regional:changed', onRegionalChanged)
    if (document.body) document.body.setAttribute(ATTR_INIT, '1')
    setTimeout(onRegionalChanged, 50)
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', attachGlobals, { once: true })
  } else {
    attachGlobals()
  }
})()
